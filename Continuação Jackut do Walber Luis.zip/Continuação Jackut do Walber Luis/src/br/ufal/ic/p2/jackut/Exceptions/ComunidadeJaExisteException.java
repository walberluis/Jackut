package br.ufal.ic.p2.jackut;

public class ComunidadeJaExisteException extends RuntimeException {
    public ComunidadeJaExisteException() {
        super("Comunidade com esse nome j� existe.");
    }
}

package br.ufal.ic.p2.jackut;

public class ComunidadeNaoExisteException extends RuntimeException {
    public ComunidadeNaoExisteException() {
        super("Comunidade n�o existe.");
    }
}
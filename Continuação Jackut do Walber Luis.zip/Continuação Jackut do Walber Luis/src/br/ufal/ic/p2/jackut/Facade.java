package br.ufal.ic.p2.jackut;

import java.io.Serializable;
import java.util.*;

public class Facade implements Serializable {
    private static final long serialVersionUID = 1L;
    private Map<String, Usuario> usuarios;
    private Map<String, String> sessoes;
    private Map<String, Comunidade> comunidades;
    private int proximoIdSessao;

    public Facade() {
        this.usuarios = new HashMap<>();
        this.sessoes = new HashMap<>();
        this.comunidades = new HashMap<>();
        this.proximoIdSessao = 1;
    }

    public void zerarSistema() {
        usuarios.clear();
        sessoes.clear();
        comunidades.clear();
        proximoIdSessao = 1;
    }

    // US1 - Cria��o de conta
    public void criarUsuario(String login, String senha, String nome) {
        if (login == null || login.isEmpty()) {
            throw new br.ufal.ic.p2.jackut.LoginInvalidoException();
        }
        if (senha == null || senha.isEmpty()) {
            throw new br.ufal.ic.p2.jackut.SenhaInvalidaException();
        }
        if (usuarios.containsKey(login)) {
            throw new br.ufal.ic.p2.jackut.UsuarioJaExisteException();
        }
        usuarios.put(login, new Usuario(login, senha, nome));
    }

    public String getAtributoUsuario(String login, String atributo) {
        Usuario usuario = usuarios.get(login);
        if (usuario == null) {
            throw new br.ufal.ic.p2.jackut.UsuarioNaoCadastradoException();
        }

        String valor = usuario.getAtributo(atributo);
        if (valor == null) {
            throw new br.ufal.ic.p2.jackut.AtributoNaoPreenchidoException();
        }
        return valor;
    }

    // US1 e US2 - Sess�o
    public String abrirSessao(String login, String senha) {
        Usuario usuario = usuarios.get(login);
        if (usuario == null || !usuario.getSenha().equals(senha)) {
            throw new br.ufal.ic.p2.jackut.LoginOuSenhaInvalidosException();
        }
        String idSessao = String.valueOf(proximoIdSessao++);
        sessoes.put(idSessao, login);
        return idSessao;
    }

    // US2 - Edi��o de perfil
    public void editarPerfil(String idSessao, String atributo, String valor) {
        validarSessao(idSessao);

        String login = sessoes.get(idSessao);
        Usuario usuario = usuarios.get(login);
        usuario.setAtributo(atributo, valor);
    }

    // US3 - Amizades
    public void adicionarAmigo(String idSessao, String amigo) {
        validarAdicaoAmigo(idSessao, amigo);

        String login = sessoes.get(idSessao);
        Usuario usuario = usuarios.get(login);
        Usuario amigoUsuario = usuarios.get(amigo);

        if (!usuarios.containsKey(amigo)) {
            throw new br.ufal.ic.p2.jackut.UsuarioNaoCadastradoException();
        }

        if (login.equals(amigo)) {
            throw new br.ufal.ic.p2.jackut.AutoAmizadeException();
        }

        if (usuario.ehInimigo(amigo) || amigoUsuario.ehInimigo(login)) {
            throw new br.ufal.ic.p2.jackut.FuncaoInvalidaException(amigoUsuario.getNome());
        }


        if (amigoUsuario.getSolicitacoesEnviadas().contains(login)) {
            usuario.adicionarAmigo(amigo);
            amigoUsuario.adicionarAmigo(login);

            usuario.getSolicitacoesRecebidas().remove(amigo);
            amigoUsuario.getSolicitacoesEnviadas().remove(login);
        } else {
            usuario.getSolicitacoesEnviadas().add(amigo);
            amigoUsuario.getSolicitacoesRecebidas().add(login);
        }
    }

    public boolean ehAmigo(String login, String amigo) {
        Usuario usuario = usuarios.get(login);
        if (usuario == null) {
            throw new br.ufal.ic.p2.jackut.UsuarioNaoCadastradoException();
        }
        return usuario.getAmigos().contains(amigo);
    }

    public String getAmigos(String login) {
        Usuario usuario = usuarios.get(login);
        if (usuario == null) {
            throw new br.ufal.ic.p2.jackut.UsuarioNaoCadastradoException();
        }

        List<String> amigosOrdenados = new ArrayList<>(usuario.getAmigos());

        amigosOrdenados.sort((a, b) -> {
            // Primeiro compara pelo tamanho (maior primeiro)
            int cmp = Integer.compare(b.length(), a.length());
            if (cmp != 0) return cmp;

            // Se mesmo tamanho, ordena alfabeticamente
            return a.compareTo(b);
        });

        return formatarLista(amigosOrdenados);
    }


    // US4 - Recados
    public void enviarRecado(String idSessao, String destinatario, String recado) {
        validarEnvioRecado(idSessao, destinatario);

        String remetente = sessoes.get(idSessao);
        Usuario usuarioDestinatario = usuarios.get(destinatario);

        Recado novoRecado = new Recado(remetente, recado);
        usuarioDestinatario.adicionarRecado(novoRecado);
    }

    public String lerRecado(String idSessao) {
        validarSessao(idSessao);
        String login = sessoes.get(idSessao);
        Usuario usuario = usuarios.get(login);

        Recado recado = usuario.lerRecado();
        if (recado == null) {
            throw new br.ufal.ic.p2.jackut.SemRecadosException();
        }
        return recado.getTexto();
    }

    // US5 - Comunidades
    public void criarComunidade(String sessao, String nome, String descricao) {
        validarSessao(sessao);

        if (nome == null || nome.isEmpty()) {
            throw new br.ufal.ic.p2.jackut.NomeComunidadeInvalidoException();
        }

        if (comunidades.containsKey(nome)) {
            throw new br.ufal.ic.p2.jackut.ComunidadeJaExisteException();
        }

        String login = sessoes.get(sessao);
        comunidades.put(nome, new Comunidade(nome, descricao, login));

        usuarios.get(login).adicionarComunidade(nome);
    }

    public String getDescricaoComunidade(String nome) {
        Comunidade comunidade = comunidades.get(nome);
        if (comunidade == null) {
            throw new br.ufal.ic.p2.jackut.ComunidadeNaoExisteException();
        }
        return comunidade.getDescricao();
    }

    public String getDonoComunidade(String nome) {
        Comunidade comunidade = comunidades.get(nome);
        if (comunidade == null) {
            throw new br.ufal.ic.p2.jackut.ComunidadeNaoExisteException();
        }
        return comunidade.getDono();
    }

    public String getMembrosComunidade(String nome) {
        Comunidade comunidade = comunidades.get(nome);
        if (comunidade == null) {
            throw new br.ufal.ic.p2.jackut.ComunidadeNaoExisteException();
        }

        String dono = comunidade.getDono();
        Set<String> outrosMembros = new TreeSet<>(comunidade.getMembros());
        outrosMembros.remove(dono);

        List<String> membrosOrdenados = new ArrayList<>();
        membrosOrdenados.add(dono);
        membrosOrdenados.addAll(outrosMembros);

        return formatarLista(membrosOrdenados);
    }

    // US6 - Adi��o a comunidades
    public void adicionarComunidade(String sessao, String nomeComunidade) {
        validarSessao(sessao);

        if (!comunidades.containsKey(nomeComunidade)) {
            throw new br.ufal.ic.p2.jackut.ComunidadeNaoExisteException();
        }

        String login = sessoes.get(sessao);
        Usuario usuario = usuarios.get(login);
        Comunidade comunidade = comunidades.get(nomeComunidade);

        if (comunidade.getMembros().contains(login)) {
            throw new br.ufal.ic.p2.jackut.UsuarioJaMembroException();
        }

        comunidade.adicionarMembro(login);
        usuario.adicionarComunidade(nomeComunidade);
    }

    public String getComunidades(String login) {
        Usuario usuario = usuarios.get(login);
        if (usuario == null) {
            throw new br.ufal.ic.p2.jackut.UsuarioNaoCadastradoException();
        }

        Set<String> comoDono = new TreeSet<>();
        Set<String> comoMembro = new TreeSet<>();

        for (String comunidade : usuario.getComunidades()) {
            Comunidade c = comunidades.get(comunidade);
            if (c == null) continue; // <<< evita erro
            if (c.getDono().equals(login)) {
                comoDono.add(comunidade);
            } else {
                comoMembro.add(comunidade);
            }
        }

        List<String> todasComunidades = new ArrayList<>();
        todasComunidades.addAll(comoDono);
        todasComunidades.addAll(comoMembro);

        return formatarLista(todasComunidades);
    }

    // US7 - Mensagens para comunidades
    public void enviarMensagem(String idSessao, String comunidade, String mensagem) {
        validarSessao(idSessao);

        if (!comunidades.containsKey(comunidade)) {
            throw new br.ufal.ic.p2.jackut.ComunidadeNaoExisteException();
        }

        String remetente = sessoes.get(idSessao);
        Comunidade com = comunidades.get(comunidade);

        for (String membro : com.getMembros()) {
            Mensagem msg = new Mensagem(remetente, comunidade, mensagem);
            usuarios.get(membro).adicionarMensagem(msg);
        }
    }
    public String lerMensagem(String idSessao) {
        validarSessao(idSessao);
        String login = sessoes.get(idSessao);
        Usuario usuario = usuarios.get(login);

        Mensagem mensagem = usuario.lerMensagem();
        if (mensagem == null) {
            throw new br.ufal.ic.p2.jackut.SemMensagensException();
        }


        return mensagem.getTexto();
    }

    private String formatarSet(Set<String> conjunto) {
        if (conjunto.isEmpty()) {
            return "{}";
        }
        StringBuilder sb = new StringBuilder("{");
        boolean first = true;
        for (String item : conjunto) {
            if (!first) {
                sb.append(",");
            }
            sb.append(item);
            first = false;
        }
        sb.append("}");
        return sb.toString();
    }

    private String formatarLista(List<String> lista) {
        if (lista.isEmpty()) {
            return "{}";
        }

        StringBuilder sb = new StringBuilder("{");
        boolean first = true;
        for (String item : lista) {
            if (!first) {
                sb.append(",");
            }
            sb.append(item);
            first = false;
        }
        sb.append("}");
        return sb.toString();
    }
    private void validarAdicaoAmigo(String idSessao, String amigo) {
        validarSessao(idSessao);

        String login = sessoes.get(idSessao);
        Usuario usuario = usuarios.get(login);

        if (!usuarios.containsKey(amigo)) {
            throw new br.ufal.ic.p2.jackut.UsuarioNaoCadastradoException();
        }

        if (login.equals(amigo)) {
            throw new br.ufal.ic.p2.jackut.AutoAmizadeException();
        }

        if (usuario.getAmigos().contains(amigo)) {
            throw new br.ufal.ic.p2.jackut.AmigoJaAdicionadoException();
        }

        if (usuario.getSolicitacoesEnviadas().contains(amigo)) {
            throw new br.ufal.ic.p2.jackut.ConvitePendenteException();
        }
    }

    private void validarEnvioRecado(String idSessao, String destinatario) {
        validarSessao(idSessao);

        if (!usuarios.containsKey(destinatario)) {
            throw new br.ufal.ic.p2.jackut.UsuarioNaoCadastradoException();
        }

        String remetente = sessoes.get(idSessao);
        if (remetente.equals(destinatario)) {
            throw new br.ufal.ic.p2.jackut.AutoRecadoException();
        }

        Usuario remetenteUsuario = usuarios.get(remetente);
        Usuario destinatarioUsuario = usuarios.get(destinatario);

        if (remetenteUsuario.ehInimigo(destinatario) || destinatarioUsuario.ehInimigo(remetente)) {
            throw new br.ufal.ic.p2.jackut.FuncaoInvalidaException(destinatarioUsuario.getNome());
        }

    }

   // US8 - Relacionamentos avan�ados

    public void adicionarIdolo(String idSessao, String idolo) {
        validarSessao(idSessao);
        String login = sessoes.get(idSessao);
        Usuario usuario = usuarios.get(login);

        if (idolo.equals(login)) {
            throw new br.ufal.ic.p2.jackut.RelacionamentoProibidoException("f�");
        }

        if (!usuarios.containsKey(idolo)) {
            throw new br.ufal.ic.p2.jackut.UsuarioNaoCadastradoException();
        }

        Usuario usuarioIdolo = usuarios.get(idolo);

        if (usuario.ehInimigo(idolo) || usuarioIdolo.ehInimigo(login)) {
            throw new br.ufal.ic.p2.jackut.FuncaoInvalidaException(usuarioIdolo.getNome());
        }

        if (usuario.ehFa(idolo)) {
            throw new br.ufal.ic.p2.jackut.UsuarioJaAdicionadoException("�dolo");
        }

        usuario.adicionarIdolo(idolo);
        usuarioIdolo.adicionarFa(login);
    }

    public boolean ehFa(String login, String idolo) {
        Usuario usuario = usuarios.get(login);
        return usuario.ehFa(idolo);
    }

    public String getFas(String login) {
        Usuario usuario = usuarios.get(login);
        if (usuario == null) {
            throw new br.ufal.ic.p2.jackut.UsuarioNaoCadastradoException();
        }
        Set<String> fas = new LinkedHashSet<>(usuario.getFas());
        return formatarSet(fas);
    }
    public void adicionarPaquera(String idSessao, String paquera) {
        validarSessao(idSessao);
        String login = sessoes.get(idSessao);

        if (paquera.equals(login)) {
            throw new br.ufal.ic.p2.jackut.RelacionamentoProibidoException("paquera");
        }

        if (!usuarios.containsKey(paquera)) {
            throw new br.ufal.ic.p2.jackut.UsuarioNaoCadastradoException();
        }

        Usuario usuario = usuarios.get(login);
        Usuario outro = usuarios.get(paquera);

        if (usuario.ehInimigo(paquera) || outro.ehInimigo(login)) {
            throw new br.ufal.ic.p2.jackut.FuncaoInvalidaException(outro.getNome());
        }

        if (usuario.ehPaquera(paquera)) {
            throw new br.ufal.ic.p2.jackut.UsuarioJaAdicionadoException("paquera");
        }

        usuario.adicionarPaquera(paquera);

        if (outro.ehPaquera(login)) {
            Recado r1 = new Recado("Jackut", outro.getNome() + " � seu paquera - Recado do Jackut.");
            Recado r2 = new Recado("Jackut", usuario.getNome() + " � seu paquera - Recado do Jackut.");
            usuario.adicionarRecado(r1);
            outro.adicionarRecado(r2);
        }
    }

    public boolean ehPaquera(String idSessao, String paquera) {
        validarSessao(idSessao);
        String login = sessoes.get(idSessao);
        Usuario usuario = usuarios.get(login);
        return usuario.ehPaquera(paquera);
    }

    public String getPaqueras(String idSessao) {
        validarSessao(idSessao);
        String login = sessoes.get(idSessao);
        Usuario usuario = usuarios.get(login);
        return formatarSet(usuario.getPaqueras());
    }

    public void adicionarInimigo(String idSessao, String inimigo) {
        validarSessao(idSessao);
        String login = sessoes.get(idSessao);

        if (inimigo.equals(login)) {
            throw new br.ufal.ic.p2.jackut.RelacionamentoProibidoException("inimigo");
        }

        if (!usuarios.containsKey(inimigo)) {
            throw new br.ufal.ic.p2.jackut.UsuarioNaoCadastradoException();
        }

        Usuario usuario = usuarios.get(login);
        if (usuario.ehInimigo(inimigo)) {
            throw new br.ufal.ic.p2.jackut.UsuarioJaAdicionadoException("inimigo");
        }

        usuario.adicionarInimigo(inimigo);
    }

    // US9 - Remo��o de conta
    public void removerUsuario(String idSessao) {
        validarSessao(idSessao);
        String login = sessoes.get(idSessao);

        if (!usuarios.containsKey(login)) {
            throw new br.ufal.ic.p2.jackut.UsuarioNaoCadastradoException();
        }

        for (Comunidade comunidade : comunidades.values()) {
            comunidade.getMembros().remove(login);
        }

        comunidades.entrySet().removeIf(entry -> entry.getValue().getDono().equals(login));

        for (Usuario outro : usuarios.values()) {
            outro.getAmigos().remove(login);
            outro.getSolicitacoesEnviadas().remove(login);
            outro.getSolicitacoesRecebidas().remove(login);

            outro.getFas().remove(login);
            outro.getIdolos().remove(login);

            outro.getPaqueras().remove(login);

            outro.getInimigos().remove(login);
        }

        for (Usuario outro : usuarios.values()) {
            if (outro.getLogin().equals(login)) continue;

            Queue<Recado> novosRecados = new LinkedList<>();
            while (true) {
                Recado r = outro.lerRecado();
                if (r == null) break;
                if (!r.getRemetente().equals(login)) {
                    novosRecados.add(r);
                }
            }
            for (Recado r : novosRecados) {
                outro.adicionarRecado(r);
            }
        }

        sessoes.values().removeIf(v -> v.equals(login));
        usuarios.remove(login);
    }

    private void validarSessao(String idSessao) {
        if (idSessao == null || idSessao.isEmpty() || !sessoes.containsKey(idSessao)) {
            throw new br.ufal.ic.p2.jackut.UsuarioNaoCadastradoException();
        }
    }

    public void encerrarSistema() {
        sessoes.clear();
        proximoIdSessao = 1;
    }
}
package br.ufal.ic.p2.jackut;

import java.io.Serializable;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedList;
import java.util.Map;
import java.util.Queue;
import java.util.Set;

public class Usuario implements Serializable {
    private static final long serialVersionUID = 1L;
    private String login;
    private String senha;
    private String nome;
    private Map<String, String> atributos;
    private Set<String> amigos;
    private Set<String> solicitacoesEnviadas;
    private Set<String> solicitacoesRecebidas;
    private Queue<Recado> recados;

    public Usuario(String login, String senha, String nome) {
        this.login = login;
        this.senha = senha;
        this.nome = nome;
        this.atributos = new HashMap<>();
        this.atributos.put("nome", nome);
        this.amigos = new HashSet<>();
        this.solicitacoesEnviadas = new HashSet<>();
        this.solicitacoesRecebidas = new HashSet<>();
        this.recados = new LinkedList<>();
    }

    // Getters b�sicos
    public String getLogin() { return login; }
    public String getSenha() { return senha; }
    public String getNome() { return nome; }

    // US2 - Atributos do perfil
    public String getAtributo(String atributo) {
        return atributos.get(atributo);
    }

    public void setAtributo(String atributo, String valor) {
        if ("nome".equals(atributo)) {
            this.nome = valor;
        }
        atributos.put(atributo, valor);
    }

    // US3 - Amizades
    public Set<String> getAmigos() {
        return amigos;
    }

    public Set<String> getSolicitacoesEnviadas() {
        return solicitacoesEnviadas;
    }

    public Set<String> getSolicitacoesRecebidas() {
        return solicitacoesRecebidas;
    }

    public void adicionarAmigo(String amigo) {
        amigos.add(amigo);
    }

    // US4 - Recados
    public void adicionarRecado(Recado recado) {
        recados.add(recado);
    }

    public Recado lerRecado() {
        return recados.poll();
    }
}
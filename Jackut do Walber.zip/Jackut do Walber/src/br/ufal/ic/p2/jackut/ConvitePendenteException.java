package br.ufal.ic.p2.jackut;

public class ConvitePendenteException extends RuntimeException {
    public ConvitePendenteException() {
        super("Usu�rio j� est� adicionado como amigo, esperando aceita��o do convite.");
    }
}


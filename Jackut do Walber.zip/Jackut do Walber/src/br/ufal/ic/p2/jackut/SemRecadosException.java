package br.ufal.ic.p2.jackut;

public class SemRecadosException extends RuntimeException {
    public SemRecadosException() {
        super("N�o h� recados.");
    }
}

package br.ufal.ic.p2.jackut;

import java.io.Serializable;
import java.util.*;

public class Facade implements Serializable {
    private static final long serialVersionUID = 1L;
    private Map<String, Usuario> usuarios;
    private Map<String, String> sessoes;
    private int proximoIdSessao;

    public Facade() {
        this.usuarios = new HashMap<>();
        this.sessoes = new HashMap<>();
        this.proximoIdSessao = 1;
    }

    public void zerarSistema() {
        usuarios.clear();
        sessoes.clear();
        proximoIdSessao = 1;
    }

    // US1 - Cria��o de conta
    public void criarUsuario(String login, String senha, String nome) {
        if (login == null || login.isEmpty()) {
            throw new LoginInvalidoException();
        }
        if (senha == null || senha.isEmpty()) {
            throw new SenhaInvalidaException();
        }
        if (usuarios.containsKey(login)) {
            throw new UsuarioJaExisteException();
        }
        usuarios.put(login, new Usuario(login, senha, nome));
    }

    public String getAtributoUsuario(String login, String atributo) {
        Usuario usuario = usuarios.get(login);
        if (usuario == null) {
            throw new UsuarioNaoCadastradoException();
        }

        String valor = usuario.getAtributo(atributo);
        if (valor == null) {
            throw new AtributoNaoPreenchidoException();
        }
        return valor;
    }

    // US1 e US2 - Sess�o
    public String abrirSessao(String login, String senha) {
        Usuario usuario = usuarios.get(login);
        if (usuario == null || !usuario.getSenha().equals(senha)) {
            throw new LoginOuSenhaInvalidosException();
        }
        String idSessao = String.valueOf(proximoIdSessao++);
        sessoes.put(idSessao, login);
        return idSessao;
    }

    // US2 - Edi��o de perfil
    public void editarPerfil(String idSessao, String atributo, String valor) {
        if (idSessao == null || idSessao.isEmpty()) {
            throw new UsuarioNaoCadastradoException();
        }

        String login = sessoes.get(idSessao);
        if (login == null) {
            throw new SessaoInvalidaException();
        }

        Usuario usuario = usuarios.get(login);
        if (usuario == null) {
            throw new UsuarioNaoCadastradoException();
        }

        usuario.setAtributo(atributo, valor);
    }

    // US3 - Amizades
    public void adicionarAmigo(String idSessao, String amigo) {
        validarAdicaoAmigo(idSessao, amigo);

        String login = sessoes.get(idSessao);
        Usuario usuario = usuarios.get(login);
        Usuario amigoUsuario = usuarios.get(amigo);

        if (amigoUsuario.getSolicitacoesEnviadas().contains(login)) {
            // Amizade m�tua
            usuario.adicionarAmigo(amigo);
            amigoUsuario.adicionarAmigo(login);

            // Remove solicita��es
            usuario.getSolicitacoesRecebidas().remove(amigo);
            amigoUsuario.getSolicitacoesEnviadas().remove(login);
        } else {
            // Envia solicita��o
            usuario.getSolicitacoesEnviadas().add(amigo);
            amigoUsuario.getSolicitacoesRecebidas().add(login);
        }
    }

    public boolean ehAmigo(String login, String amigo) {
        Usuario usuario = usuarios.get(login);
        if (usuario == null) {
            throw new UsuarioNaoCadastradoException();
        }
        return usuario.getAmigos().contains(amigo);
    }

    public String getAmigos(String login) {
        Usuario usuario = usuarios.get(login);
        if (usuario == null) {
            throw new UsuarioNaoCadastradoException();
        }

        Set<String> amigos = usuario.getAmigos();
        if (amigos.isEmpty()) {
            return "{}";
        }

        List<String> amigosOrdenados = new ArrayList<>(amigos);
        amigosOrdenados.sort((a, b) -> {
            int lengthCompare = Integer.compare(b.length(), a.length());
            if (lengthCompare != 0) {
                return lengthCompare;
            }
            return a.compareTo(b);
        });

        StringBuilder sb = new StringBuilder("{");
        boolean first = true;
        for (String amigo : amigosOrdenados) {
            if (!first) {
                sb.append(",");
            }
            sb.append(amigo);
            first = false;
        }
        sb.append("}");

        return sb.toString();
    }

    // US4 - Recados
    public void enviarRecado(String idSessao, String destinatario, String recado) {
        validarEnvioRecado(idSessao, destinatario);

        String remetente = sessoes.get(idSessao);
        Usuario usuarioDestinatario = usuarios.get(destinatario);

        Recado novoRecado = new Recado(remetente, recado);
        usuarioDestinatario.adicionarRecado(novoRecado);
    }

    public String lerRecado(String idSessao) {
        validarSessao(idSessao);
        String login = sessoes.get(idSessao);
        Usuario usuario = usuarios.get(login);

        Recado recado = usuario.lerRecado();
        if (recado == null) {
            throw new SemRecadosException();
        }
        return recado.getTexto();
    }

    // M�todos auxiliares
    private void validarAdicaoAmigo(String idSessao, String amigo) {
        if (idSessao == null || !sessoes.containsKey(idSessao)) {
            throw new UsuarioNaoCadastradoException();
        }

        String login = sessoes.get(idSessao);
        Usuario usuario = usuarios.get(login);

        if (!usuarios.containsKey(amigo)) {
            throw new UsuarioNaoCadastradoException();
        }

        if (login.equals(amigo)) {
            throw new AutoAmizadeException();
        }

        if (usuario.getAmigos().contains(amigo)) {
            throw new AmigoJaAdicionadoException();
        }

        if (usuario.getSolicitacoesEnviadas().contains(amigo)) {
            throw new ConvitePendenteException();
        }
    }

    private void validarEnvioRecado(String idSessao, String destinatario) {
        validarSessao(idSessao);

        if (!usuarios.containsKey(destinatario)) {
            throw new UsuarioNaoCadastradoException();
        }

        String remetente = sessoes.get(idSessao);
        if (remetente.equals(destinatario)) {
            throw new AutoRecadoException();
        }
    }

    private void validarSessao(String idSessao) {
        if (idSessao == null || idSessao.isEmpty() || !sessoes.containsKey(idSessao)) {
            throw new SessaoInvalidaException();
        }
    }

    public void encerrarSistema() {
        sessoes.clear();
        proximoIdSessao = 1;
    }
}
package br.ufal.ic.p2.jackut;

public class AutoAmizadeException extends RuntimeException {
    public AutoAmizadeException() {
        super("Usu�rio n�o pode adicionar a si mesmo como amigo.");
    }
}


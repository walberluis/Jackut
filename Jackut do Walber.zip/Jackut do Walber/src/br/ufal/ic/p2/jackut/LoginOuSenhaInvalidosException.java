package br.ufal.ic.p2.jackut;

public class LoginOuSenhaInvalidosException extends RuntimeException {
    public LoginOuSenhaInvalidosException() {
        super("Login ou senha inv�lidos.");
    }
}



package br.ufal.ic.p2.jackut;

public class AutoRecadoException extends RuntimeException {
    public AutoRecadoException() {
        super("Usu�rio n�o pode enviar recado para si mesmo.");
    }
}


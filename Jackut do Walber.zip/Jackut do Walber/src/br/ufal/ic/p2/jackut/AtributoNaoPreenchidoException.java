package br.ufal.ic.p2.jackut;

public class AtributoNaoPreenchidoException extends RuntimeException {
    public AtributoNaoPreenchidoException() {
        super("Atributo n�o preenchido.");
    }
}


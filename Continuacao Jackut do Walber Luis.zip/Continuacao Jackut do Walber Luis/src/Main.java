import easyaccept.EasyAccept;

public class Main {
    public static void main(String[] args) {
        String[] args1 = {"br.ufal.ic.p2.jackut.Facade",
                "tests/us1_1.txt", "tests/us1_2.txt"
        };

        String[] args2 = {"br.ufal.ic.p2.jackut.Facade",
                "tests/us2_1.txt", "tests/us2_2.txt"
        };

        String[] args3 = {"br.ufal.ic.p2.jackut.Facade",
                "tests/us3_1.txt", "tests/us3_2.txt"
        };

        String[] args4 = {"br.ufal.ic.p2.jackut.Facade",
                "tests/us4_1.txt", "tests/us4_2.txt"
        };

        String[] args5 = {"br.ufal.ic.p2.jackut.Facade",
                "tests/us5_1.txt", "tests/us5_2.txt"
        };

        String[] args6 = {"br.ufal.ic.p2.jackut.Facade",
                "tests/us6_1.txt", "tests/us6_2.txt"
        };

        String[] args7 = {"br.ufal.ic.p2.jackut.Facade",
                "tests/us7_1.txt", "tests/us7_2.txt"
        };

        String[] args8 = {"br.ufal.ic.p2.jackut.Facade",
                "tests/us8_1.txt", "tests/us8_2.txt"
        };

        String[] args9 = {"br.ufal.ic.p2.jackut.Facade",
                "tests/us9_1.txt", "tests/us9_2.txt"
        };

        EasyAccept.main(args1);
        EasyAccept.main(args2);
        EasyAccept.main(args3);
        EasyAccept.main(args4);
        EasyAccept.main(args5);
        EasyAccept.main(args6);
        EasyAccept.main(args7);
        EasyAccept.main(args8);
        EasyAccept.main(args9);

    }
}
package br.ufal.ic.p2.jackut;

/**
 * Exce��o lan�ada quando � tentada uma opera��o com uma comunidade que n�o existe.
 */
public class ComunidadeNaoExisteException extends RuntimeException {
    /**
     * Constr�i a exce��o com uma mensagem padr�o.
     */
    public ComunidadeNaoExisteException() {
        super("Comunidade n�o existe.");
    }
}
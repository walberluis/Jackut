package br.ufal.ic.p2.jackut;

public class SenhaInvalidaException extends RuntimeException {
    public SenhaInvalidaException() {
        super("Senha inv�lida.");
    }
}


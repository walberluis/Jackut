package br.ufal.ic.p2.jackut;

public class UsuarioJaExisteException extends RuntimeException {
    public UsuarioJaExisteException() {
        super("Conta com esse nome j� existe.");
    }
}


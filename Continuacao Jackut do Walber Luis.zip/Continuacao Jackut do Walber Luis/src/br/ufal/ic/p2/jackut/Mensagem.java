package br.ufal.ic.p2.jackut;

import java.io.Serializable;

public class Mensagem implements Serializable {
    private static final long serialVersionUID = 1L;
    private String remetente;
    private String comunidade;
    private String texto;

    public Mensagem(String remetente, String comunidade, String texto) {
        this.remetente = remetente;
        this.comunidade = comunidade;
        this.texto = texto;
    }

    public String getRemetente() {
        return remetente;
    }

    public String getComunidade() {
        return comunidade;
    }

    public String getTexto() {
        return texto;
    }

}
package br.ufal.ic.p2.jackut;

import java.io.Serializable;
import java.util.*;

public class Usuario implements Serializable {
    private static final long serialVersionUID = 1L;
    private String login;
    private String senha;
    private String nome;
    private Map<String, String> atributos;
    private Set<String> amigos;
    private Set<String> solicitacoesEnviadas;
    private Set<String> solicitacoesRecebidas;
    private Queue<Recado> recados;
    private Set<String> comunidades;
    private Queue<Mensagem> mensagens;
    private Set<String> idolos = new HashSet<>();
    private Set<String> fas = new LinkedHashSet<>(); // Mant�m ordem de inser��o
    private Set<String> paqueras = new HashSet<>();
    private Set<String> inimigos = new HashSet<>();



    public Usuario(String login, String senha, String nome) {
        this.login = login;
        this.senha = senha;
        this.nome = nome;
        this.atributos = new HashMap<>();
        this.atributos.put("nome", nome);
        this.amigos = new HashSet<>();
        this.solicitacoesEnviadas = new HashSet<>();
        this.solicitacoesRecebidas = new HashSet<>();
        this.recados = new LinkedList<>();
        this.comunidades = new HashSet<>();
        this.mensagens = new LinkedList<>();
        this.idolos = new HashSet<>();
        this.fas = new HashSet<>();
        this.paqueras = new HashSet<>();
        this.inimigos = new HashSet<>();
    }

    // Getters e Setters
    public String getLogin() { return login; }
    public String getSenha() { return senha; }
    public String getNome() { return nome; }

    public String getAtributo(String atributo) {
        return atributos.get(atributo);
    }

    public void setAtributo(String atributo, String valor) {
        if ("nome".equals(atributo)) {
            this.nome = valor;
        }
        atributos.put(atributo, valor);
    }

    // Amizades
    public Set<String> getAmigos()
    {
        return amigos;
    }

    public void adicionarAmigo(String amigo)
    {
        amigos.add(amigo);
    }

    // Solicita��es
    public Set<String> getSolicitacoesEnviadas()
    {
        return solicitacoesEnviadas;
    }
    public Set<String> getSolicitacoesRecebidas()
    {
        return solicitacoesRecebidas;
    }

    // Recados
    public void adicionarRecado(Recado recado)
    {
        recados.add(recado);
    }

    public Recado lerRecado()
    {
        return recados.poll();
    }

    // Comunidades
    public Set<String> getComunidades()
    {
        return comunidades;
    }

    public void adicionarComunidade(String comunidade)
    {
        comunidades.add(comunidade);
    }

    // Mensagens
    public void adicionarMensagem(Mensagem mensagem)
    {
        mensagens.add(mensagem);
    }
    public Mensagem lerMensagem()
    {
        return mensagens.poll();
    }
    public boolean temMensagens()
    {
        return !mensagens.isEmpty();
    }

    // F�s e �dolos
    public void adicionarIdolo(String idolo) {
        idolos.add(idolo);
    }
    public boolean ehFa(String idolo) {
        return idolos.contains(idolo);
    }
    public void adicionarFa(String fa) {
        fas.add(fa);
    }
    public Set<String> getFas() {
        return new HashSet<>(fas); // c�pia defensiva
    }

    // Paquera
    public void adicionarPaquera(String paquera) {
        paqueras.add(paquera);
    }
    public boolean ehPaquera(String paquera) {
        return paqueras.contains(paquera);
    }
    public Set<String> getPaqueras() {
        return paqueras;
    }

    // Inimigos
    public void adicionarInimigo(String inimigo) {
        inimigos.add(inimigo);
    }
    public boolean ehInimigo(String outro) {
        return inimigos.contains(outro);
    }

    public Set<String> getIdolos() {
        return idolos;
    }

    public Set<String> getInimigos() {
        return inimigos;
    }

}
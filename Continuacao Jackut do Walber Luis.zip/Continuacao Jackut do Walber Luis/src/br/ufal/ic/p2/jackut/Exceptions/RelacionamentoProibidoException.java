package br.ufal.ic.p2.jackut;

public class RelacionamentoProibidoException extends RuntimeException {
    public RelacionamentoProibidoException(String mensagem) {
        super("Usu�rio n�o pode ser " + mensagem + " de si mesmo.");
    }
}

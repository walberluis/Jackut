package br.ufal.ic.p2.jackut;

/**
 * Exce��o lan�ada quando um usu�rio tenta ler mensagens, mas n�o h� mensagens dispon�veis.
 */
public class SemMensagensException extends RuntimeException {
    /**
     * Constr�i a exce��o com uma mensagem padr�o.
     */
    public SemMensagensException() {
        super("N�o h� mensagens.");
    }
}

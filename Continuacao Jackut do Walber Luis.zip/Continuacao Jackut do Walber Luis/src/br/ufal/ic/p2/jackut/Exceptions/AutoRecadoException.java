package br.ufal.ic.p2.jackut;

/**
 * Exce��o lan�ada quando um usu�rio tenta enviar um recado para si mesmo.
 */
public class AutoRecadoException extends RuntimeException {
    /**
     * Constr�i a exce��o com uma mensagem padr�o sobre auto-recado.
     */
    public AutoRecadoException() {
        super("Usu�rio n�o pode enviar recado para si mesmo.");
    }
}

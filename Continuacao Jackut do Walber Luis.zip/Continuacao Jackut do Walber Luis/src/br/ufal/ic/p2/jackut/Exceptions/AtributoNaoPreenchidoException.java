package br.ufal.ic.p2.jackut;

/**
 * Exce��o lan�ada quando � tentado acessar um atributo de usu�rio que n�o foi preenchido.
 */
public class AtributoNaoPreenchidoException extends RuntimeException {
    /**
     * Constr�i a exce��o com uma mensagem padr�o.
     */
    public AtributoNaoPreenchidoException() {
        super("Atributo n�o preenchido.");
    }
}

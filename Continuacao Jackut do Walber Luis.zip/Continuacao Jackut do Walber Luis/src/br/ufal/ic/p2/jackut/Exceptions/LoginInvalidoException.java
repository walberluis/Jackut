package br.ufal.ic.p2.jackut;

public class LoginInvalidoException extends RuntimeException {
    public LoginInvalidoException() {
        super("Login inv�lido.");
    }
}

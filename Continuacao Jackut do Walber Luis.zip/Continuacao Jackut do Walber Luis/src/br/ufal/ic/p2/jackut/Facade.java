package br.ufal.ic.p2.jackut;

import java.io.Serializable;
import java.util.*;

/**
 * Classe que representa a fachada do sistema Jackut, fornecendo uma interface simplificada
 * para todas as opera��es do sistema. Implementa Serializable para permitir serializa��o.
 *
 * <p>A fachada gerencia sess�es de usu�rio e delega as opera��es para a classe Sistema.</p>
 *
 * @author Sistema Jackut
 * @version 1.0
 */
public class Facade implements Serializable {
    private static final long serialVersionUID = 1L;
    private Sistema sistema;
    private Map<String, String> sessoes;

    /**
     * Constr�i uma nova fachada, inicializando o sistema e o mapa de sess�es.
     */
    public Facade() {
        this.sistema = new Sistema();
        this.sessoes = new HashMap<>();
    }

    /**
     * Reinicia o sistema, removendo todos os usu�rios, comunidades e sess�es.
     */
    public void zerarSistema() {
        sistema.zerarSistema();
        sessoes.clear();
    }

    /**
     * Cria um novo usu�rio no sistema.
     *
     * @param login Login do usu�rio (deve ser �nico)
     * @param senha Senha do usu�rio
     * @param nome Nome do usu�rio
     * @throws LoginInvalidoException Se o login for nulo ou vazio
     * @throws SenhaInvalidaException Se a senha for nula ou vazia
     * @throws UsuarioJaExisteException Se o login j� estiver em uso
     */
    public void criarUsuario(String login, String senha, String nome) {
        sistema.criarUsuario(login, senha, nome);
    }

    /**
     * Obt�m um atributo de um usu�rio.
     *
     * @param login Login do usu�rio
     * @param atributo Nome do atributo a ser obtido
     * @return Valor do atributo solicitado
     * @throws UsuarioNaoCadastradoException Se o usu�rio n�o existir
     * @throws AtributoNaoPreenchidoException Se o atributo n�o estiver definido
     */
    public String getAtributoUsuario(String login, String atributo) {
        return sistema.getAtributoUsuario(login, atributo);
    }

    /**
     * Abre uma nova sess�o para o usu�rio.
     *
     * @param login Login do usu�rio
     * @param senha Senha do usu�rio
     * @return ID da sess�o criada
     * @throws LoginOuSenhaInvalidosException Se o login ou senha estiverem incorretos
     */
    public String abrirSessao(String login, String senha) {
        String idSessao = sistema.abrirSessao(login, senha);
        sessoes.put(idSessao, login);
        return idSessao;
    }

    /**
     * Edita um atributo do perfil do usu�rio logado.
     *
     * @param idSessao ID da sess�o do usu�rio
     * @param atributo Nome do atributo a ser editado
     * @param valor Novo valor para o atributo
     * @throws UsuarioNaoCadastradoException Se a sess�o for inv�lida
     */
    public void editarPerfil(String idSessao, String atributo, String valor) {
        validarSessao(idSessao);
        String login = sessoes.get(idSessao);
        sistema.editarPerfil(login, atributo, valor);
    }

    /**
     * Adiciona um amigo para o usu�rio logado.
     *
     * @param idSessao ID da sess�o do usu�rio
     * @param amigo Login do amigo a ser adicionado
     * @throws UsuarioNaoCadastradoException Se a sess�o for inv�lida ou o amigo n�o existir
     * @throws AutoAmizadeException Se tentar adicionar a si mesmo como amigo
     * @throws AmigoJaAdicionadoException Se j� forem amigos
     * @throws ConvitePendenteException Se j� houver um convite pendente
     * @throws FuncaoInvalidaException Se os usu�rios forem inimigos
     */
    public void adicionarAmigo(String idSessao, String amigo) {
        validarSessao(idSessao);
        String login = sessoes.get(idSessao);
        sistema.adicionarAmigo(login, amigo);
    }

    /**
     * Verifica se dois usu�rios s�o amigos.
     *
     * @param login Login do primeiro usu�rio
     * @param amigo Login do segundo usu�rio
     * @return true se forem amigos, false caso contr�rio
     * @throws UsuarioNaoCadastradoException Se algum dos usu�rios n�o existir
     */
    public boolean ehAmigo(String login, String amigo) {
        return sistema.ehAmigo(login, amigo);
    }

    /**
     * Obt�m a lista de amigos de um usu�rio.
     *
     * @param login Login do usu�rio
     * @return String formatada com a lista de amigos
     * @throws UsuarioNaoCadastradoException Se o usu�rio n�o existir
     */
    public String getAmigos(String login) {
        return sistema.getAmigos(login);
    }

    /**
     * Envia um recado para outro usu�rio.
     *
     * @param idSessao ID da sess�o do remetente
     * @param destinatario Login do destinat�rio
     * @param recado Texto do recado
     * @throws UsuarioNaoCadastradoException Se a sess�o for inv�lida ou o destinat�rio n�o existir
     * @throws AutoRecadoException Se tentar enviar recado para si mesmo
     * @throws FuncaoInvalidaException Se os usu�rios forem inimigos
     */
    public void enviarRecado(String idSessao, String destinatario, String recado) {
        validarSessao(idSessao);
        String remetente = sessoes.get(idSessao);
        sistema.enviarRecado(remetente, destinatario, recado);
    }

    /**
     * L� o pr�ximo recado n�o lido do usu�rio logado.
     *
     * @param idSessao ID da sess�o do usu�rio
     * @return Texto do recado
     * @throws UsuarioNaoCadastradoException Se a sess�o for inv�lida
     * @throws SemRecadosException Se n�o houver recados para ler
     */
    public String lerRecado(String idSessao) {
        validarSessao(idSessao);
        String login = sessoes.get(idSessao);
        return sistema.lerRecado(login);
    }

    /**
     * Cria uma nova comunidade.
     *
     * @param sessao ID da sess�o do criador
     * @param nome Nome da comunidade
     * @param descricao Descri��o da comunidade
     * @throws UsuarioNaoCadastradoException Se a sess�o for inv�lida
     * @throws NomeComunidadeInvalidoException Se o nome for nulo ou vazio
     * @throws ComunidadeJaExisteException Se j� existir uma comunidade com esse nome
     */
    public void criarComunidade(String sessao, String nome, String descricao) {
        validarSessao(sessao);
        String login = sessoes.get(sessao);
        sistema.criarComunidade(login, nome, descricao);
    }

    /**
     * Obt�m a descri��o de uma comunidade.
     *
     * @param nome Nome da comunidade
     * @return Descri��o da comunidade
     * @throws ComunidadeNaoExisteException Se a comunidade n�o existir
     */
    public String getDescricaoComunidade(String nome) {
        return sistema.getDescricaoComunidade(nome);
    }

    /**
     * Obt�m o dono de uma comunidade.
     *
     * @param nome Nome da comunidade
     * @return Login do dono da comunidade
     * @throws ComunidadeNaoExisteException Se a comunidade n�o existir
     */
    public String getDonoComunidade(String nome) {
        return sistema.getDonoComunidade(nome);
    }

    /**
     * Obt�m a lista de membros de uma comunidade.
     *
     * @param nome Nome da comunidade
     * @return String formatada com a lista de membros
     * @throws ComunidadeNaoExisteException Se a comunidade n�o existir
     */
    public String getMembrosComunidade(String nome) {
        return sistema.getMembrosComunidade(nome);
    }

    /**
     * Adiciona o usu�rio logado a uma comunidade.
     *
     * @param sessao ID da sess�o do usu�rio
     * @param nomeComunidade Nome da comunidade
     * @throws UsuarioNaoCadastradoException Se a sess�o for inv�lida
     * @throws ComunidadeNaoExisteException Se a comunidade n�o existir
     * @throws UsuarioJaMembroException Se o usu�rio j� for membro da comunidade
     */
    public void adicionarComunidade(String sessao, String nomeComunidade) {
        validarSessao(sessao);
        String login = sessoes.get(sessao);
        sistema.adicionarComunidade(login, nomeComunidade);
    }

    /**
     * Obt�m a lista de comunidades de um usu�rio.
     *
     * @param login Login do usu�rio
     * @return String formatada com a lista de comunidades
     * @throws UsuarioNaoCadastradoException Se o usu�rio n�o existir
     */
    public String getComunidades(String login) {
        return sistema.getComunidades(login);
    }

    /**
     * Envia uma mensagem para todos os membros de uma comunidade.
     *
     * @param idSessao ID da sess�o do remetente
     * @param comunidade Nome da comunidade
     * @param mensagem Texto da mensagem
     * @throws UsuarioNaoCadastradoException Se a sess�o for inv�lida
     * @throws ComunidadeNaoExisteException Se a comunidade n�o existir
     */
    public void enviarMensagem(String idSessao, String comunidade, String mensagem) {
        validarSessao(idSessao);
        String remetente = sessoes.get(idSessao);
        sistema.enviarMensagem(remetente, comunidade, mensagem);
    }

    /**
     * L� a pr�xima mensagem n�o lida do usu�rio logado.
     *
     * @param idSessao ID da sess�o do usu�rio
     * @return Texto da mensagem
     * @throws UsuarioNaoCadastradoException Se a sess�o for inv�lida
     * @throws SemMensagensException Se n�o houver mensagens para ler
     */
    public String lerMensagem(String idSessao) {
        validarSessao(idSessao);
        String login = sessoes.get(idSessao);
        return sistema.lerMensagem(login);
    }

    /**
     * Adiciona um �dolo para o usu�rio logado.
     *
     * @param idSessao ID da sess�o do usu�rio
     * @param idolo Login do �dolo a ser adicionado
     * @throws UsuarioNaoCadastradoException Se a sess�o for inv�lida ou o �dolo n�o existir
     * @throws RelacionamentoProibidoException Se tentar adicionar a si mesmo como �dolo
     * @throws FuncaoInvalidaException Se os usu�rios forem inimigos
     * @throws UsuarioJaAdicionadoException Se j� for f� desse �dolo
     */
    public void adicionarIdolo(String idSessao, String idolo) {
        validarSessao(idSessao);
        String login = sessoes.get(idSessao);
        sistema.adicionarIdolo(login, idolo);
    }

    /**
     * Verifica se um usu�rio � f� de outro.
     *
     * @param login Login do poss�vel f�
     * @param idolo Login do poss�vel �dolo
     * @return true se for f�, false caso contr�rio
     */
    public boolean ehFa(String login, String idolo) {
        return sistema.ehFa(login, idolo);
    }

    /**
     * Obt�m a lista de f�s de um usu�rio.
     *
     * @param login Login do usu�rio
     * @return String formatada com a lista de f�s
     * @throws UsuarioNaoCadastradoException Se o usu�rio n�o existir
     */
    public String getFas(String login) {
        return sistema.getFas(login);
    }

    /**
     * Adiciona uma paquera para o usu�rio logado.
     *
     * @param idSessao ID da sess�o do usu�rio
     * @param paquera Login da paquera a ser adicionada
     * @throws UsuarioNaoCadastradoException Se a sess�o for inv�lida ou a paquera n�o existir
     * @throws RelacionamentoProibidoException Se tentar adicionar a si mesmo como paquera
     * @throws FuncaoInvalidaException Se os usu�rios forem inimigos
     * @throws UsuarioJaAdicionadoException Se j� tiver essa paquera
     */
    public void adicionarPaquera(String idSessao, String paquera) {
        validarSessao(idSessao);
        String login = sessoes.get(idSessao);
        sistema.adicionarPaquera(login, paquera);
    }

    /**
     * Verifica se um usu�rio tem uma paquera por outro.
     *
     * @param idSessao ID da sess�o do usu�rio
     * @param paquera Login da poss�vel paquera
     * @return true se for paquera, false caso contr�rio
     * @throws UsuarioNaoCadastradoException Se a sess�o for inv�lida
     */
    public boolean ehPaquera(String idSessao, String paquera) {
        validarSessao(idSessao);
        String login = sessoes.get(idSessao);
        return sistema.ehPaquera(login, paquera);
    }

    /**
     * Obt�m a lista de paqueras do usu�rio logado.
     *
     * @param idSessao ID da sess�o do usu�rio
     * @return String formatada com a lista de paqueras
     * @throws UsuarioNaoCadastradoException Se a sess�o for inv�lida
     */
    public String getPaqueras(String idSessao) {
        validarSessao(idSessao);
        String login = sessoes.get(idSessao);
        return sistema.getPaqueras(login);
    }

    /**
     * Adiciona um inimigo para o usu�rio logado.
     *
     * @param idSessao ID da sess�o do usu�rio
     * @param inimigo Login do inimigo a ser adicionado
     * @throws UsuarioNaoCadastradoException Se a sess�o for inv�lida ou o inimigo n�o existir
     * @throws RelacionamentoProibidoException Se tentar adicionar a si mesmo como inimigo
     * @throws UsuarioJaAdicionadoException Se j� tiver esse inimigo
     */
    public void adicionarInimigo(String idSessao, String inimigo) {
        validarSessao(idSessao);
        String login = sessoes.get(idSessao);
        sistema.adicionarInimigo(login, inimigo);
    }

    /**
     * Remove o usu�rio logado do sistema.
     *
     * @param idSessao ID da sess�o do usu�rio
     * @throws UsuarioNaoCadastradoException Se a sess�o for inv�lida
     */
    public void removerUsuario(String idSessao) {
        validarSessao(idSessao);
        String login = sessoes.get(idSessao);
        sistema.removerUsuario(login);
        sessoes.values().removeIf(v -> v.equals(login));
    }

    /**
     * Altera a estrat�gia de notifica��o de um usu�rio
     * @param login Login do usu�rio
     * @param strategy Nova estrat�gia de notifica��o
     */
    public void setEstrategiaNotificacao(String login, NotificacaoStrategy strategy) {
        validarSessao(login); // Valida se o usu�rio existe
        sistema.getUsuario(login).setNotificacaoStrategy(strategy);
    }

    /**
     * Valida se uma sess�o existe e � v�lida.
     *
     * @param idSessao ID da sess�o a ser validada
     * @throws UsuarioNaoCadastradoException Se a sess�o for inv�lida
     */
    private void validarSessao(String idSessao) {
        if (idSessao == null || idSessao.isEmpty() || !sessoes.containsKey(idSessao)) {
            throw new br.ufal.ic.p2.jackut.UsuarioNaoCadastradoException();
        }
    }

    /**
     * Encerra o sistema, limpando todas as sess�es ativas.
     */
    public void encerrarSistema() {
        sessoes.clear();
    }
}
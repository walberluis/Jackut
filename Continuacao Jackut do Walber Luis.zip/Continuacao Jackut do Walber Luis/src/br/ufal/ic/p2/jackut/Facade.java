package br.ufal.ic.p2.jackut;

import java.io.Serializable;
import java.util.*;

public class Facade implements Serializable {
    private static final long serialVersionUID = 1L;
    private Sistema sistema;
    private Map<String, String> sessoes;

    public Facade() {
        this.sistema = new Sistema();
        this.sessoes = new HashMap<>();
    }

    public void zerarSistema() {
        sistema.zerarSistema();
        sessoes.clear();
    }

    // US1 - Cria��o de conta
    public void criarUsuario(String login, String senha, String nome) {
        sistema.criarUsuario(login, senha, nome);
    }

    public String getAtributoUsuario(String login, String atributo) {
        return sistema.getAtributoUsuario(login, atributo);
    }

    // US1 e US2 - Sess�o
    public String abrirSessao(String login, String senha) {
        String idSessao = sistema.abrirSessao(login, senha);
        sessoes.put(idSessao, login);
        return idSessao;
    }

    // US2 - Edi��o de perfil
    public void editarPerfil(String idSessao, String atributo, String valor) {
        validarSessao(idSessao);
        String login = sessoes.get(idSessao);
        sistema.editarPerfil(login, atributo, valor);
    }

    // US3 - Amizades
    public void adicionarAmigo(String idSessao, String amigo) {
        validarSessao(idSessao);
        String login = sessoes.get(idSessao);
        sistema.adicionarAmigo(login, amigo);
    }

    public boolean ehAmigo(String login, String amigo) {
        return sistema.ehAmigo(login, amigo);
    }

    public String getAmigos(String login) {
        return sistema.getAmigos(login);
    }

    // US4 - Recados
    public void enviarRecado(String idSessao, String destinatario, String recado) {
        validarSessao(idSessao);
        String remetente = sessoes.get(idSessao);
        sistema.enviarRecado(remetente, destinatario, recado);
    }

    public String lerRecado(String idSessao) {
        validarSessao(idSessao);
        String login = sessoes.get(idSessao);
        return sistema.lerRecado(login);
    }

    // US5 - Comunidades
    public void criarComunidade(String sessao, String nome, String descricao) {
        validarSessao(sessao);
        String login = sessoes.get(sessao);
        sistema.criarComunidade(login, nome, descricao);
    }

    public String getDescricaoComunidade(String nome) {
        return sistema.getDescricaoComunidade(nome);
    }

    public String getDonoComunidade(String nome) {
        return sistema.getDonoComunidade(nome);
    }

    public String getMembrosComunidade(String nome) {
        return sistema.getMembrosComunidade(nome);
    }

    // US6 - Adi��o a comunidades
    public void adicionarComunidade(String sessao, String nomeComunidade) {
        validarSessao(sessao);
        String login = sessoes.get(sessao);
        sistema.adicionarComunidade(login, nomeComunidade);
    }

    public String getComunidades(String login) {
        return sistema.getComunidades(login);
    }

    // US7 - Mensagens para comunidades
    public void enviarMensagem(String idSessao, String comunidade, String mensagem) {
        validarSessao(idSessao);
        String remetente = sessoes.get(idSessao);
        sistema.enviarMensagem(remetente, comunidade, mensagem);
    }

    public String lerMensagem(String idSessao) {
        validarSessao(idSessao);
        String login = sessoes.get(idSessao);
        return sistema.lerMensagem(login);
    }

    // US8 - Relacionamentos avan�ados
    public void adicionarIdolo(String idSessao, String idolo) {
        validarSessao(idSessao);
        String login = sessoes.get(idSessao);
        sistema.adicionarIdolo(login, idolo);
    }

    public boolean ehFa(String login, String idolo) {
        return sistema.ehFa(login, idolo);
    }

    public String getFas(String login) {
        return sistema.getFas(login);
    }

    public void adicionarPaquera(String idSessao, String paquera) {
        validarSessao(idSessao);
        String login = sessoes.get(idSessao);
        sistema.adicionarPaquera(login, paquera);
    }

    public boolean ehPaquera(String idSessao, String paquera) {
        validarSessao(idSessao);
        String login = sessoes.get(idSessao);
        return sistema.ehPaquera(login, paquera);
    }

    public String getPaqueras(String idSessao) {
        validarSessao(idSessao);
        String login = sessoes.get(idSessao);
        return sistema.getPaqueras(login);
    }

    public void adicionarInimigo(String idSessao, String inimigo) {
        validarSessao(idSessao);
        String login = sessoes.get(idSessao);
        sistema.adicionarInimigo(login, inimigo);
    }

    // US9 - Remo��o de conta
    public void removerUsuario(String idSessao) {
        validarSessao(idSessao);
        String login = sessoes.get(idSessao);
        sistema.removerUsuario(login);
        sessoes.values().removeIf(v -> v.equals(login));
    }

    private void validarSessao(String idSessao) {
        if (idSessao == null || idSessao.isEmpty() || !sessoes.containsKey(idSessao)) {
            throw new br.ufal.ic.p2.jackut.UsuarioNaoCadastradoException();
        }
    }

    public void encerrarSistema() {
        sessoes.clear();
    }
}
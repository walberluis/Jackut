package br.ufal.ic.p2.jackut;

/**
 * Exce��o lan�ada quando � fornecido um nome inv�lido para uma comunidade
 * (vazio ou nulo).
 */
public class NomeComunidadeInvalidoException extends RuntimeException {
    /**
     * Constr�i a exce��o com uma mensagem padr�o.
     */
    public NomeComunidadeInvalidoException() {
        super("Nome de comunidade inv�lido.");
    }
}
package br.ufal.ic.p2.jackut;

public class NomeComunidadeInvalidoException extends RuntimeException {
    public NomeComunidadeInvalidoException() {
        super("Nome de comunidade inv�lido.");
    }
}
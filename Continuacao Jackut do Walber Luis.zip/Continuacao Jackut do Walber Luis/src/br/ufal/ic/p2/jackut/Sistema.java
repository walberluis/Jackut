package br.ufal.ic.p2.jackut;

import java.io.Serializable;
import java.util.*;

/**
 * Classe principal do sistema Jackut, respons�vel por gerenciar usu�rios, comunidades
 * e todas as intera��es entre eles. Implementa Serializable para permitir serializa��o.
 *
 * <p>Esta classe cont�m a l�gica de neg�cios do sistema e � utilizada pela classe Facade.</p>
 *
 * @author Sistema Jackut
 * @version 1.0
 */
public class Sistema implements Serializable {
    private static final long serialVersionUID = 1L;
    private Map<String, Usuario> usuarios;
    private Map<String, Comunidade> comunidades;
    private int proximoIdSessao;

    /**
     * Constr�i um novo sistema, inicializando as estruturas de dados necess�rias.
     */
    public Sistema() {
        this.usuarios = new HashMap<>();
        this.comunidades = new HashMap<>();
        this.proximoIdSessao = 1;
    }

    /**
     * Reinicia o sistema, removendo todos os usu�rios e comunidades.
     */
    public void zerarSistema() {
        usuarios.clear();
        comunidades.clear();
        proximoIdSessao = 1;
    }

    /**
     * Cria um novo usu�rio no sistema.
     *
     * @param login Login do usu�rio (deve ser �nico)
     * @param senha Senha do usu�rio
     * @param nome Nome do usu�rio
     * @throws LoginInvalidoException Se o login for nulo ou vazio
     * @throws SenhaInvalidaException Se a senha for nula ou vazia
     * @throws UsuarioJaExisteException Se o login j� estiver em uso
     */
    public void criarUsuario(String login, String senha, String nome) {
        if (login == null || login.isEmpty()) {
            throw new br.ufal.ic.p2.jackut.LoginInvalidoException();
        }
        if (usuarios.containsKey(login)) {
            throw new br.ufal.ic.p2.jackut.UsuarioJaExisteException();
        }

        Usuario novoUsuario = new Usuario(login, senha, nome);
        novoUsuario.setNotificacaoStrategy(new ConsoleNotificacao()); // Padr�o
        usuarios.put(login, novoUsuario);
    }

    /**
     * Obt�m um atributo de um usu�rio.
     *
     * @param login Login do usu�rio
     * @param atributo Nome do atributo a ser obtido
     * @return Valor do atributo solicitado
     * @throws UsuarioNaoCadastradoException Se o usu�rio n�o existir
     * @throws AtributoNaoPreenchidoException Se o atributo n�o estiver definido
     */
    public String getAtributoUsuario(String login, String atributo) {
        Usuario usuario = usuarios.get(login);
        if (usuario == null) {
            throw new br.ufal.ic.p2.jackut.UsuarioNaoCadastradoException();
        }

        String valor = usuario.getAtributo(atributo);
        if (valor == null) {
            throw new br.ufal.ic.p2.jackut.AtributoNaoPreenchidoException();
        }
        return valor;
    }

    /**
     * Abre uma nova sess�o para o usu�rio.
     *
     * @param login Login do usu�rio
     * @param senha Senha do usu�rio
     * @return ID da sess�o criada
     * @throws LoginOuSenhaInvalidosException Se o login ou senha estiverem incorretos
     */
    public String abrirSessao(String login, String senha) {
        Usuario usuario = usuarios.get(login);
        if (usuario == null || !usuario.getSenha().equals(senha)) {
            throw new br.ufal.ic.p2.jackut.LoginOuSenhaInvalidosException();
        }
        return String.valueOf(proximoIdSessao++);
    }

    /**
     * Edita um atributo do perfil de um usu�rio.
     *
     * @param login Login do usu�rio
     * @param atributo Nome do atributo a ser editado
     * @param valor Novo valor para o atributo
     * @throws UsuarioNaoCadastradoException Se o usu�rio n�o existir
     */
    public void editarPerfil(String login, String atributo, String valor) {
        Usuario usuario = usuarios.get(login);
        usuario.setAtributo(atributo, valor);
    }

    /**
     * Adiciona um amigo para um usu�rio.
     *
     * @param login Login do usu�rio que est� adicionando
     * @param amigo Login do amigo a ser adicionado
     * @throws UsuarioNaoCadastradoException Se algum dos usu�rios n�o existir
     * @throws AutoAmizadeException Se tentar adicionar a si mesmo como amigo
     * @throws AmigoJaAdicionadoException Se j� forem amigos
     * @throws ConvitePendenteException Se j� houver um convite pendente
     * @throws FuncaoInvalidaException Se os usu�rios forem inimigos
     */
    public void adicionarAmigo(String login, String amigo) {
        Usuario usuario = usuarios.get(login);
        Usuario amigoUsuario = usuarios.get(amigo);

        if (!usuarios.containsKey(amigo)) {
            throw new br.ufal.ic.p2.jackut.UsuarioNaoCadastradoException();
        }

        if (login.equals(amigo)) {
            throw new br.ufal.ic.p2.jackut.AutoAmizadeException();
        }

        if (usuario.getAmigos().contains(amigo)) {
            throw new br.ufal.ic.p2.jackut.AmigoJaAdicionadoException();
        }

        if (usuario.getSolicitacoesEnviadas().contains(amigo)) {
            throw new br.ufal.ic.p2.jackut.ConvitePendenteException();
        }

        if (usuario.ehInimigo(amigo) || amigoUsuario.ehInimigo(login)) {
            throw new br.ufal.ic.p2.jackut.FuncaoInvalidaException(amigoUsuario.getNome());
        }

        if (amigoUsuario.getSolicitacoesEnviadas().contains(login)) {
            usuario.adicionarAmigo(amigo);
            amigoUsuario.adicionarAmigo(login);

            usuario.getSolicitacoesRecebidas().remove(amigo);
            amigoUsuario.getSolicitacoesEnviadas().remove(login);
        } else {
            usuario.getSolicitacoesEnviadas().add(amigo);
            amigoUsuario.getSolicitacoesRecebidas().add(login);
        }
    }

    /**
     * Verifica se dois usu�rios s�o amigos.
     *
     * @param login Login do primeiro usu�rio
     * @param amigo Login do segundo usu�rio
     * @return true se forem amigos, false caso contr�rio
     * @throws UsuarioNaoCadastradoException Se o primeiro usu�rio n�o existir
     */
    public boolean ehAmigo(String login, String amigo) {
        Usuario usuario = usuarios.get(login);
        if (usuario == null) {
            throw new br.ufal.ic.p2.jackut.UsuarioNaoCadastradoException();
        }
        return usuario.getAmigos().contains(amigo);
    }

    /**
     * Obt�m a lista de amigos de um usu�rio, ordenada por tamanho do login (decrescente)
     * e alfabeticamente em caso de empate.
     *
     * @param login Login do usu�rio
     * @return String formatada com a lista de amigos
     * @throws UsuarioNaoCadastradoException Se o usu�rio n�o existir
     */
    public String getAmigos(String login) {
        Usuario usuario = usuarios.get(login);
        if (usuario == null) {
            throw new br.ufal.ic.p2.jackut.UsuarioNaoCadastradoException();
        }

        List<String> amigosOrdenados = new ArrayList<>(usuario.getAmigos());
        amigosOrdenados.sort((a, b) -> {
            int cmp = Integer.compare(b.length(), a.length());
            if (cmp != 0) return cmp;
            return a.compareTo(b);
        });

        return formatarLista(amigosOrdenados);
    }

    /**
     * Envia um recado de um usu�rio para outro.
     *
     * @param remetente Login do remetente
     * @param destinatario Login do destinat�rio
     * @param recado Texto do recado
     * @throws UsuarioNaoCadastradoException Se algum dos usu�rios n�o existir
     * @throws AutoRecadoException Se tentar enviar recado para si mesmo
     * @throws FuncaoInvalidaException Se os usu�rios forem inimigos
     */
    public void enviarRecado(String remetente, String destinatario, String recado) {
        if (!usuarios.containsKey(destinatario)) {
            throw new br.ufal.ic.p2.jackut.UsuarioNaoCadastradoException();
        }

        if (remetente.equals(destinatario)) {
            throw new br.ufal.ic.p2.jackut.AutoRecadoException();
        }

        Usuario remetenteUsuario = usuarios.get(remetente);
        Usuario destinatarioUsuario = usuarios.get(destinatario);

        if (remetenteUsuario.ehInimigo(destinatario) || destinatarioUsuario.ehInimigo(remetente)) {
            throw new br.ufal.ic.p2.jackut.FuncaoInvalidaException(destinatarioUsuario.getNome());
        }

        Recado novoRecado = new Recado(remetente, recado);
        destinatarioUsuario.adicionarRecado(novoRecado);
    }

    /**
     * L� o pr�ximo recado n�o lido de um usu�rio.
     *
     * @param login Login do usu�rio
     * @return Texto do recado
     * @throws UsuarioNaoCadastradoException Se o usu�rio n�o existir
     * @throws SemRecadosException Se n�o houver recados para ler
     */
    public String lerRecado(String login) {
        Usuario usuario = usuarios.get(login);
        Recado recado = usuario.lerRecado();
        if (recado == null) {
            throw new br.ufal.ic.p2.jackut.SemRecadosException();
        }
        return recado.getTexto();
    }

    /**
     * Cria uma nova comunidade.
     *
     * @param login Login do criador (que ser� o dono)
     * @param nome Nome da comunidade
     * @param descricao Descri��o da comunidade
     * @throws NomeComunidadeInvalidoException Se o nome for nulo ou vazio
     * @throws ComunidadeJaExisteException Se j� existir uma comunidade com esse nome
     */
    public void criarComunidade(String login, String nome, String descricao) {
        if (nome == null || nome.isEmpty()) {
            throw new br.ufal.ic.p2.jackut.NomeComunidadeInvalidoException();
        }

        if (comunidades.containsKey(nome)) {
            throw new br.ufal.ic.p2.jackut.ComunidadeJaExisteException();
        }

        comunidades.put(nome, new Comunidade(nome, descricao, login));
        usuarios.get(login).adicionarComunidade(nome);
    }

    /**
     * Obt�m a descri��o de uma comunidade.
     *
     * @param nome Nome da comunidade
     * @return Descri��o da comunidade
     * @throws ComunidadeNaoExisteException Se a comunidade n�o existir
     */
    public String getDescricaoComunidade(String nome) {
        Comunidade comunidade = comunidades.get(nome);
        if (comunidade == null) {
            throw new br.ufal.ic.p2.jackut.ComunidadeNaoExisteException();
        }
        return comunidade.getDescricao();
    }

    /**
     * Obt�m o dono de uma comunidade.
     *
     * @param nome Nome da comunidade
     * @return Login do dono da comunidade
     * @throws ComunidadeNaoExisteException Se a comunidade n�o existir
     */
    public String getDonoComunidade(String nome) {
        Comunidade comunidade = comunidades.get(nome);
        if (comunidade == null) {
            throw new br.ufal.ic.p2.jackut.ComunidadeNaoExisteException();
        }
        return comunidade.getDono();
    }

    /**
     * Obt�m a lista de membros de uma comunidade, com o dono primeiro e os demais
     * membros em ordem alfab�tica.
     *
     * @param nome Nome da comunidade
     * @return String formatada com a lista de membros
     * @throws ComunidadeNaoExisteException Se a comunidade n�o existir
     */
    public String getMembrosComunidade(String nome) {
        Comunidade comunidade = comunidades.get(nome);
        if (comunidade == null) {
            throw new br.ufal.ic.p2.jackut.ComunidadeNaoExisteException();
        }

        String dono = comunidade.getDono();
        Set<String> outrosMembros = new TreeSet<>(comunidade.getMembros());
        outrosMembros.remove(dono);

        List<String> membrosOrdenados = new ArrayList<>();
        membrosOrdenados.add(dono);
        membrosOrdenados.addAll(outrosMembros);

        return formatarLista(membrosOrdenados);
    }

    /**
     * Adiciona um usu�rio a uma comunidade.
     *
     * @param login Login do usu�rio
     * @param nomeComunidade Nome da comunidade
     * @throws ComunidadeNaoExisteException Se a comunidade n�o existir
     * @throws UsuarioJaMembroException Se o usu�rio j� for membro da comunidade
     */
    public void adicionarComunidade(String login, String nomeComunidade) {
        if (!comunidades.containsKey(nomeComunidade)) {
            throw new br.ufal.ic.p2.jackut.ComunidadeNaoExisteException();
        }

        Usuario usuario = usuarios.get(login);
        Comunidade comunidade = comunidades.get(nomeComunidade);

        if (comunidade.getMembros().contains(login)) {
            throw new br.ufal.ic.p2.jackut.UsuarioJaMembroException();
        }

        comunidade.adicionarMembro(login);
        usuario.adicionarComunidade(nomeComunidade);
    }

    /**
     * Obt�m a lista de comunidades de um usu�rio, separadas entre as que ele � dono
     * e as que � apenas membro, em ordem alfab�tica.
     *
     * @param login Login do usu�rio
     * @return String formatada com a lista de comunidades
     * @throws UsuarioNaoCadastradoException Se o usu�rio n�o existir
     */
    public String getComunidades(String login) {
        Usuario usuario = usuarios.get(login);
        if (usuario == null) {
            throw new br.ufal.ic.p2.jackut.UsuarioNaoCadastradoException();
        }

        Set<String> comoDono = new TreeSet<>();
        Set<String> comoMembro = new TreeSet<>();

        for (String comunidade : usuario.getComunidades()) {
            Comunidade c = comunidades.get(comunidade);
            if (c == null) continue;
            if (c.getDono().equals(login)) {
                comoDono.add(comunidade);
            } else {
                comoMembro.add(comunidade);
            }
        }

        List<String> todasComunidades = new ArrayList<>();
        todasComunidades.addAll(comoDono);
        todasComunidades.addAll(comoMembro);

        return formatarLista(todasComunidades);
    }

    /**
     * Envia uma mensagem para todos os membros de uma comunidade.
     *
     * @param remetente Login do remetente
     * @param comunidade Nome da comunidade
     * @param mensagem Texto da mensagem
     * @throws ComunidadeNaoExisteException Se a comunidade n�o existir
     */
    public void enviarMensagem(String remetente, String comunidade, String mensagem) {
        if (!comunidades.containsKey(comunidade)) {
            throw new br.ufal.ic.p2.jackut.ComunidadeNaoExisteException();
        }

        Comunidade com = comunidades.get(comunidade);
        for (String membro : com.getMembros()) {
            Mensagem msg = new Mensagem(remetente, comunidade, mensagem);
            usuarios.get(membro).adicionarMensagem(msg);
        }
    }

    /**
     * L� a pr�xima mensagem n�o lida de um usu�rio.
     *
     * @param login Login do usu�rio
     * @return Texto da mensagem
     * @throws UsuarioNaoCadastradoException Se o usu�rio n�o existir
     * @throws SemMensagensException Se n�o houver mensagens para ler
     */
    public String lerMensagem(String login) {
        Usuario usuario = usuarios.get(login);
        Mensagem mensagem = usuario.lerMensagem();
        if (mensagem == null) {
            throw new br.ufal.ic.p2.jackut.SemMensagensException();
        }
        return mensagem.getTexto();
    }

    /**
     * Adiciona um �dolo para um usu�rio.
     *
     * @param login Login do f�
     * @param idolo Login do �dolo
     * @throws RelacionamentoProibidoException Se tentar adicionar a si mesmo como �dolo
     * @throws UsuarioNaoCadastradoException Se o �dolo n�o existir
     * @throws FuncaoInvalidaException Se os usu�rios forem inimigos
     * @throws UsuarioJaAdicionadoException Se j� for f� desse �dolo
     */
    public void adicionarIdolo(String login, String idolo) {
        if (idolo.equals(login)) {
            throw new br.ufal.ic.p2.jackut.RelacionamentoProibidoException("f�");
        }

        if (!usuarios.containsKey(idolo)) {
            throw new br.ufal.ic.p2.jackut.UsuarioNaoCadastradoException();
        }

        Usuario usuario = usuarios.get(login);
        Usuario usuarioIdolo = usuarios.get(idolo);

        if (usuario.ehInimigo(idolo) || usuarioIdolo.ehInimigo(login)) {
            throw new br.ufal.ic.p2.jackut.FuncaoInvalidaException(usuarioIdolo.getNome());
        }

        if (usuario.ehFa(idolo)) {
            throw new br.ufal.ic.p2.jackut.UsuarioJaAdicionadoException("�dolo");
        }

        usuario.adicionarIdolo(idolo);
        usuarioIdolo.adicionarFa(login);
    }

    /**
     * Verifica se um usu�rio � f� de outro.
     *
     * @param login Login do poss�vel f�
     * @param idolo Login do poss�vel �dolo
     * @return true se for f�, false caso contr�rio
     */
    public boolean ehFa(String login, String idolo) {
        Usuario usuario = usuarios.get(login);
        return usuario.ehFa(idolo);
    }

    /**
     * Obt�m a lista de f�s de um usu�rio.
     *
     * @param login Login do usu�rio
     * @return String formatada com a lista de f�s
     * @throws UsuarioNaoCadastradoException Se o usu�rio n�o existir
     */
    public String getFas(String login) {
        Usuario usuario = usuarios.get(login);
        if (usuario == null) {
            throw new br.ufal.ic.p2.jackut.UsuarioNaoCadastradoException();
        }
        Set<String> fas = new LinkedHashSet<>(usuario.getFas());
        return formatarSet(fas);
    }

    /**
     * Adiciona uma paquera para um usu�rio.
     *
     * @param login Login do usu�rio
     * @param paquera Login da paquera
     * @throws RelacionamentoProibidoException Se tentar adicionar a si mesmo como paquera
     * @throws UsuarioNaoCadastradoException Se a paquera n�o existir
     * @throws FuncaoInvalidaException Se os usu�rios forem inimigos
     * @throws UsuarioJaAdicionadoException Se j� tiver essa paquera
     */
    public void adicionarPaquera(String login, String paquera) {
        if (paquera.equals(login)) {
            throw new br.ufal.ic.p2.jackut.RelacionamentoProibidoException("paquera");
        }

        if (!usuarios.containsKey(paquera)) {
            throw new br.ufal.ic.p2.jackut.UsuarioNaoCadastradoException();
        }

        Usuario usuario = usuarios.get(login);
        Usuario outro = usuarios.get(paquera);

        if (usuario.ehInimigo(paquera) || outro.ehInimigo(login)) {
            throw new br.ufal.ic.p2.jackut.FuncaoInvalidaException(outro.getNome());
        }

        if (usuario.ehPaquera(paquera)) {
            throw new br.ufal.ic.p2.jackut.UsuarioJaAdicionadoException("paquera");
        }

        usuario.adicionarPaquera(paquera);

        if (outro.ehPaquera(login)) {
            Recado r1 = new Recado("Jackut", outro.getNome() + " � seu paquera - Recado do Jackut.");
            Recado r2 = new Recado("Jackut", usuario.getNome() + " � seu paquera - Recado do Jackut.");
            usuario.adicionarRecado(r1);
            outro.adicionarRecado(r2);
        }
    }

    /**
     * Verifica se um usu�rio tem uma paquera por outro.
     *
     * @param login Login do usu�rio
     * @param paquera Login da poss�vel paquera
     * @return true se for paquera, false caso contr�rio
     */
    public boolean ehPaquera(String login, String paquera) {
        Usuario usuario = usuarios.get(login);
        return usuario.ehPaquera(paquera);
    }

    /**
     * Obt�m a lista de paqueras de um usu�rio.
     *
     * @param login Login do usu�rio
     * @return String formatada com a lista de paqueras
     */
    public String getPaqueras(String login) {
        Usuario usuario = usuarios.get(login);
        return formatarSet(usuario.getPaqueras());
    }

    /**
     * Adiciona um inimigo para um usu�rio.
     *
     * @param login Login do usu�rio
     * @param inimigo Login do inimigo
     * @throws RelacionamentoProibidoException Se tentar adicionar a si mesmo como inimigo
     * @throws UsuarioNaoCadastradoException Se o inimigo n�o existir
     * @throws UsuarioJaAdicionadoException Se j� tiver esse inimigo
     */
    public void adicionarInimigo(String login, String inimigo) {
        if (inimigo.equals(login)) {
            throw new br.ufal.ic.p2.jackut.RelacionamentoProibidoException("inimigo");
        }

        if (!usuarios.containsKey(inimigo)) {
            throw new br.ufal.ic.p2.jackut.UsuarioNaoCadastradoException();
        }

        Usuario usuario = usuarios.get(login);
        if (usuario.ehInimigo(inimigo)) {
            throw new br.ufal.ic.p2.jackut.UsuarioJaAdicionadoException("inimigo");
        }

        usuario.adicionarInimigo(inimigo);
    }

    /**
     * Remove um usu�rio do sistema, limpando todas as suas refer�ncias.
     *
     * @param login Login do usu�rio a ser removido
     * @throws UsuarioNaoCadastradoException Se o usu�rio n�o existir
     */
    public void removerUsuario(String login) {
        if (!usuarios.containsKey(login)) {
            throw new br.ufal.ic.p2.jackut.UsuarioNaoCadastradoException();
        }

        // Remove de todas as comunidades
        for (Comunidade comunidade : comunidades.values()) {
            comunidade.getMembros().remove(login);
        }

        // Remove comunidades onde era dono
        comunidades.entrySet().removeIf(entry -> entry.getValue().getDono().equals(login));

        // Remove de todas as listas de relacionamentos
        for (Usuario outro : usuarios.values()) {
            outro.getAmigos().remove(login);
            outro.getSolicitacoesEnviadas().remove(login);
            outro.getSolicitacoesRecebidas().remove(login);

            outro.getFas().remove(login);
            outro.getIdolos().remove(login);

            outro.getPaqueras().remove(login);
            outro.getInimigos().remove(login);
        }

        // Remove refer�ncias em recados
        for (Usuario outro : usuarios.values()) {
            if (outro.getLogin().equals(login)) continue;

            Queue<Recado> novosRecados = new LinkedList<>();
            while (true) {
                Recado r = outro.lerRecado();
                if (r == null) break;
                if (!r.getRemetente().equals(login)) {
                    novosRecados.add(r);
                }
            }
            for (Recado r : novosRecados) {
                outro.adicionarRecado(r);
            }
        }

        usuarios.remove(login);
    }

    /**
     * Formata um conjunto de strings para exibi��o.
     *
     * @param conjunto Conjunto de strings a ser formatado
     * @return String formatada no formato {item1,item2,...}
     */
    private String formatarSet(Set<String> conjunto) {
        if (conjunto.isEmpty()) {
            return "{}";
        }
        StringBuilder sb = new StringBuilder("{");
        boolean first = true;
        for (String item : conjunto) {
            if (!first) {
                sb.append(",");
            }
            sb.append(item);
            first = false;
        }
        sb.append("}");
        return sb.toString();
    }

    /**
     * Formata uma lista de strings para exibi��o.
     *
     * @param lista Lista de strings a ser formatada
     * @return String formatada no formato {item1,item2,...}
     */
    private String formatarLista(List<String> lista) {
        if (lista.isEmpty()) {
            return "{}";
        }
        StringBuilder sb = new StringBuilder("{");
        boolean first = true;
        for (String item : lista) {
            if (!first) {
                sb.append(",");
            }
            sb.append(item);
            first = false;
        }
        sb.append("}");
        return sb.toString();
    }

    /**
     * Verifica se um usu�rio existe no sistema.
     *
     * @param login Login do usu�rio a ser verificado
     * @return true se o usu�rio existir, false caso contr�rio
     */
    public boolean existeUsuario(String login) {
        return usuarios.containsKey(login);
    }

    public Usuario getUsuario(String login) {
        return usuarios.get(login);
    }
}
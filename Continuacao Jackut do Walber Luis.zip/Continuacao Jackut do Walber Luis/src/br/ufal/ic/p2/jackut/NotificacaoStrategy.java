package br.ufal.ic.p2.jackut;

/**
 * Interface para estrat�gias de notifica��o
 */
public interface NotificacaoStrategy {
    /**
     * Envia uma notifica��o para o usu�rio
     * @param destinatario Login do usu�rio destinat�rio
     * @param mensagem Conte�do da notifica��o
     */
    void enviarNotificacao(String destinatario, String mensagem);
}
package br.ufal.ic.p2.jackut;

/**
 * Exce��o lan�ada quando um usu�rio tenta enviar um convite de amizade para outro usu�rio
 * que j� possui um convite pendente.
 */
public class ConvitePendenteException extends RuntimeException {
    /**
     * Constr�i a exce��o com uma mensagem padr�o sobre convite pendente.
     */
    public ConvitePendenteException() {
        super("Usu�rio j� est� adicionado como amigo, esperando aceita��o do convite.");
    }
}

package br.ufal.ic.p2.jackut;

public class UsuarioJaAdicionadoException extends RuntimeException {
  public UsuarioJaAdicionadoException(String mensagem)
  {
    super("Usu�rio j� est� adicionado como " + mensagem + ".");
  }
}
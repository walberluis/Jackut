package br.ufal.ic.p2.jackut;

/**
 * Exce��o lan�ada quando uma opera��o tenta usar uma sess�o inv�lida (inexistente ou expirada).
 */
public class SessaoInvalidaException extends RuntimeException {
    /**
     * Constr�i a exce��o com uma mensagem padr�o sobre sess�o inv�lida.
     */
    public SessaoInvalidaException() {
        super("Sess�o inv�lida.");
    }
}
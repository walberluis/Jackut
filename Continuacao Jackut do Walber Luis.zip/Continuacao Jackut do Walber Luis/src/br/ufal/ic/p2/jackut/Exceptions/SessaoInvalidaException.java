package br.ufal.ic.p2.jackut;

public class SessaoInvalidaException extends RuntimeException {
    public SessaoInvalidaException() {
        super("Sess�o inv�lida.");
    }
}

package br.ufal.ic.p2.jackut;

/**
 * Estrat�gia de notifica��o que n�o faz nada (para testes)
 */
public class FakeNotificacao implements NotificacaoStrategy {
    @Override
    public void enviarNotificacao(String destinatario, String mensagem) {
        // Implementa��o vazia para testes
    }
}
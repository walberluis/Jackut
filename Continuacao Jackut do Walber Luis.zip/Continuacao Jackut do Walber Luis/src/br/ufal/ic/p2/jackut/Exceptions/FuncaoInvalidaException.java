package br.ufal.ic.p2.jackut;

/**
 * Exce��o lan�ada quando um usu�rio tenta estabelecer um relacionamento com outro
 * usu�rio que � seu inimigo, o que n�o � permitido pelo sistema.
 */
public class FuncaoInvalidaException extends RuntimeException {
    /**
     * Constr�i a exce��o com o nome do usu�rio que � inimigo.
     *
     * @param message O nome do usu�rio que � inimigo
     */
    public FuncaoInvalidaException(String message) {
        super("Fun��o inv�lida: " + message + " � seu inimigo.");
    }
}
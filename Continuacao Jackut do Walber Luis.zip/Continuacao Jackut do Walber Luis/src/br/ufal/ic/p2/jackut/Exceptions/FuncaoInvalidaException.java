package br.ufal.ic.p2.jackut;

public class FuncaoInvalidaException extends RuntimeException {
    public FuncaoInvalidaException(String message) {
        super("Fun��o inv�lida: " + message + " � seu inimigo.");
    }
}
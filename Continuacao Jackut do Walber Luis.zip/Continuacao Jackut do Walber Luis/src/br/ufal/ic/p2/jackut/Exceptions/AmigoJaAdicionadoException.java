package br.ufal.ic.p2.jackut;

/**
 * Exce��o lan�ada quando um usu�rio tenta adicionar como amigo outro usu�rio
 * que j� est� em sua lista de amigos.
 */
public class AmigoJaAdicionadoException extends RuntimeException {
    /**
     * Constr�i a exce��o com uma mensagem padr�o.
     */
    public AmigoJaAdicionadoException() {
        super("Usu�rio j� est� adicionado como amigo.");
    }
}
package br.ufal.ic.p2.jackut;

/**
 * Exce��o lan�ada quando um usu�rio tenta entrar em uma comunidade da qual j� � membro.
 */
public class UsuarioJaMembroException extends RuntimeException {
    /**
     * Constr�i a exce��o com uma mensagem padr�o.
     */
    public UsuarioJaMembroException() {
        super("Usuario j� faz parte dessa comunidade.");
    }
}
package br.ufal.ic.p2.jackut;

/**
 * Exce��o lan�ada quando � tentada a cria��o de uma comunidade com nome que j� existe.
 */
public class ComunidadeJaExisteException extends RuntimeException {
    /**
     * Constr�i a exce��o com uma mensagem padr�o.
     */
    public ComunidadeJaExisteException() {
        super("Comunidade com esse nome j� existe.");
    }
}
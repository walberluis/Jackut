package br.ufal.ic.p2.jackut;

/**
 * Exce��o lan�ada quando uma opera��o tenta acessar um usu�rio que n�o est� cadastrado no sistema.
 */
public class UsuarioNaoCadastradoException extends RuntimeException {
    /**
     * Constr�i a exce��o com uma mensagem padr�o indicando que o usu�rio n�o est� cadastrado.
     */
    public UsuarioNaoCadastradoException() {
        super("Usu�rio n�o cadastrado.");
    }
}

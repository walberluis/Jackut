package br.ufal.ic.p2.jackut.Exceptions;

/**
 * Exce��o lan�ada quando um usu�rio tenta adicionar a si mesmo como amigo.
 */
public class AutoAmizadeException extends RuntimeException {
    /**
     * Constr�i a exce��o com uma mensagem padr�o sobre autoamizade.
     */
    public AutoAmizadeException() {
        super("Usu�rio n�o pode adicionar a si mesmo como amigo.");
    }
}

package br.ufal.ic.p2.jackut.Models;

import java.io.Serializable;

/**
 * Classe que representa uma mensagem enviada para uma comunidade no sistema Jackut.
 * Implementa Serializable para permitir serializa��o.
 *
 * <p>Cada mensagem cont�m o remetente, a comunidade destinat�ria e o texto da mensagem.</p>
 *
 * @author Sistema Jackut
 * @version 1.0
 */
public class Mensagem implements Serializable {
    private static final long serialVersionUID = 1L;
    private String remetente;
    private String comunidade;
    private String texto;

    /**
     * Constr�i uma nova mensagem com os dados fornecidos.
     *
     * @param remetente Login do remetente
     * @param comunidade Nome da comunidade destinat�ria
     * @param texto Conte�do da mensagem
     */
    public Mensagem(String remetente, String comunidade, String texto) {
        this.remetente = remetente;
        this.comunidade = comunidade;
        this.texto = texto;
    }

    /**
     * Obt�m o login do remetente da mensagem.
     *
     * @return Login do remetente
     */
    public String getRemetente() {
        return remetente;
    }

    /**
     * Obt�m o nome da comunidade destinat�ria da mensagem.
     *
     * @return Nome da comunidade
     */
    public String getComunidade() {
        return comunidade;
    }

    /**
     * Obt�m o texto da mensagem.
     *
     * @return Conte�do da mensagem
     */
    public String getTexto() {
        return texto;
    }
}
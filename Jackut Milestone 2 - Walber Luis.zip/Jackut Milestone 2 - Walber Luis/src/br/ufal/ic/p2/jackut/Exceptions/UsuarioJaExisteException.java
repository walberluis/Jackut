package br.ufal.ic.p2.jackut.Exceptions;

/**
 * Exce��o lan�ada quando � tentado cadastrar um usu�rio com login j� existente no sistema.
 */
public class UsuarioJaExisteException extends RuntimeException {
    /**
     * Constr�i a exce��o com uma mensagem padr�o sobre usu�rio j� existente.
     */
    public UsuarioJaExisteException() {
        super("Conta com esse nome j� existe.");
    }
}
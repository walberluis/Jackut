package br.ufal.ic.p2.jackut.Exceptions;

/**
 * Exce��o lan�ada quando um usu�rio tenta ler recados, mas n�o h� recados dispon�veis.
 */
public class SemRecadosException extends RuntimeException {
    /**
     * Constr�i a exce��o com uma mensagem padr�o sobre aus�ncia de recados.
     */
    public SemRecadosException() {
        super("N�o h� recados.");
    }
}
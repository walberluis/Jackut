package br.ufal.ic.p2.jackut.Models;

import java.io.Serializable;
import java.util.HashSet;
import java.util.Set;

/**
 * Classe que representa uma comunidade no sistema Jackut.
 * Implementa Serializable para permitir serializa��o.
 *
 * <p>Cada comunidade possui um nome, descri��o, dono e conjunto de membros.
 * O dono � automaticamente adicionado como membro ao criar a comunidade.</p>
 *
 * @author Sistema Jackut
 * @version 1.0
 */
public class Comunidade implements Serializable {
    private static final long serialVersionUID = 1L;
    private String nome;
    private String descricao;
    private String dono;
    private Set<String> membros;

    /**
     * Constr�i uma nova comunidade com os dados fornecidos.
     *
     * @param nome Nome da comunidade (deve ser �nico)
     * @param descricao Descri��o da comunidade
     * @param dono Login do usu�rio criador/dono da comunidade
     */
    public Comunidade(String nome, String descricao, String dono) {
        this.nome = nome;
        this.descricao = descricao;
        this.dono = dono;
        this.membros = new HashSet<>();
        this.membros.add(dono);
    }

    /**
     * Obt�m o nome da comunidade.
     *
     * @return Nome da comunidade
     */
    public String getNome() {
        return nome;
    }

    /**
     * Obt�m a descri��o da comunidade.
     *
     * @return Descri��o da comunidade
     */
    public String getDescricao() {
        return descricao;
    }

    /**
     * Obt�m o login do dono da comunidade.
     *
     * @return Login do dono
     */
    public String getDono() {
        return dono;
    }

    /**
     * Obt�m o conjunto de membros da comunidade.
     *
     * @return Conjunto de logins dos membros (incluindo o dono)
     */
    public Set<String> getMembros() {
        return membros;
    }

    /**
     * Adiciona um novo membro � comunidade.
     *
     * @param login Login do usu�rio a ser adicionado
     */
    public void adicionarMembro(String login) {
        membros.add(login);
    }
}
package br.ufal.ic.p2.jackut.Models;

/**
 * Estrat�gia de notifica��o que exibe mensagens no console
 */
public class ConsoleNotificacao implements NotificacaoStrategy {
    @Override
    public void enviarNotificacao(String destinatario, String mensagem) {
    }
}
package br.ufal.ic.p2.jackut.Exceptions;

/**
 * Exce��o lan�ada quando � fornecida uma senha inv�lida (vazia ou nula) durante o cadastro.
 */
public class SenhaInvalidaException extends RuntimeException {
    /**
     * Constr�i a exce��o com uma mensagem padr�o sobre senha inv�lida.
     */
    public SenhaInvalidaException() {
        super("Senha inv�lida.");
    }
}
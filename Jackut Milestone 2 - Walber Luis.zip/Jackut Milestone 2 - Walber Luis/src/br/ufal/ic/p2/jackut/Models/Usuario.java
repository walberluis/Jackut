package br.ufal.ic.p2.jackut.Models;

import java.io.Serializable;
import java.util.*;

/**
 * Classe que representa um usu�rio do sistema Jackut, contendo todas as informa��es
 * e relacionamentos do usu�rio. Implementa Serializable para permitir serializa��o.
 *
 * <p>Esta classe armazena os dados b�sicos do usu�rio, seus relacionamentos (amigos, �dolos, etc.),
 * recados, mensagens e comunidades �s quais pertence.</p>
 *
 * @author Sistema Jackut
 * @version 1.0
 */
public class Usuario implements Serializable {
    private static final long serialVersionUID = 1L;
    private String login;
    private String senha;
    private String nome;
    private Map<String, String> atributos;
    private Set<String> amigos;
    private Set<String> solicitacoesEnviadas;
    private Set<String> solicitacoesRecebidas;
    private Queue<Recado> recados;
    private Set<String> comunidades;
    private Queue<Mensagem> mensagens;
    private Set<String> idolos = new HashSet<>();
    private Set<String> fas = new LinkedHashSet<>(); // Mant�m ordem de inser��o
    private Set<String> paqueras = new HashSet<>();
    private Set<String> inimigos = new HashSet<>();
    private transient NotificacaoStrategy notificacaoStrategy = new ConsoleNotificacao();


    /**
     * Constr�i um novo usu�rio com os dados b�sicos.
     *
     * @param login Login �nico do usu�rio
     * @param senha Senha do usu�rio
     * @param nome Nome do usu�rio
     */
    public Usuario(String login, String senha, String nome) {
        this.login = login;
        this.senha = senha;
        this.nome = nome;
        this.atributos = new HashMap<>();
        this.atributos.put("nome", nome);
        this.amigos = new HashSet<>();
        this.solicitacoesEnviadas = new HashSet<>();
        this.solicitacoesRecebidas = new HashSet<>();
        this.recados = new LinkedList<>();
        this.comunidades = new HashSet<>();
        this.mensagens = new LinkedList<>();
        this.idolos = new HashSet<>();
        this.fas = new HashSet<>();
        this.paqueras = new HashSet<>();
        this.inimigos = new HashSet<>();
    }

    /**
     * Obt�m o login do usu�rio.
     *
     * @return Login do usu�rio
     */
    public String getLogin() { return login; }

    /**
     * Obt�m a senha do usu�rio.
     *
     * @return Senha do usu�rio
     */
    public String getSenha() { return senha; }

    /**
     * Obt�m o nome do usu�rio.
     *
     * @return Nome do usu�rio
     */
    public String getNome() { return nome; }

    /**
     * Obt�m o valor de um atributo do usu�rio.
     *
     * @param atributo Nome do atributo
     * @return Valor do atributo ou null se n�o existir
     */
    public String getAtributo(String atributo) {
        return atributos.get(atributo);
    }

    /**
     * Define ou atualiza um atributo do usu�rio.
     *
     * @param atributo Nome do atributo
     * @param valor Novo valor do atributo
     */
    public void setAtributo(String atributo, String valor) {
        if ("nome".equals(atributo)) {
            this.nome = valor;
        }
        atributos.put(atributo, valor);
    }

    // Amizades

    /**
     * Obt�m o conjunto de amigos do usu�rio.
     *
     * @return Conjunto de logins dos amigos
     */
    public Set<String> getAmigos() {
        return amigos;
    }

    /**
     * Adiciona um amigo ao usu�rio.
     *
     * @param amigo Login do amigo a ser adicionado
     */
    public void adicionarAmigo(String amigo) {
        amigos.add(amigo);
    }

    // Solicita��es

    /**
     * Obt�m o conjunto de solicita��es de amizade enviadas pelo usu�rio.
     *
     * @return Conjunto de logins para onde foram enviadas solicita��es
     */
    public Set<String> getSolicitacoesEnviadas() {
        return solicitacoesEnviadas;
    }

    /**
     * Obt�m o conjunto de solicita��es de amizade recebidas pelo usu�rio.
     *
     * @return Conjunto de logins de quem enviou solicita��es
     */
    public Set<String> getSolicitacoesRecebidas() {
        return solicitacoesRecebidas;
    }

    // Recados

    /**
     * Adiciona um novo recado para o usu�rio.
     *
     * @param recado Recado a ser adicionado
     */
    public void adicionarRecado(Recado recado) {
        recados.add(recado);
        if (notificacaoStrategy != null) {
            notificacaoStrategy.enviarNotificacao(this.login,
                    "Novo recado de " + recado.getRemetente() + ": " + recado.getTexto());
        }
    }


    /**
     * L� e remove o pr�ximo recado n�o lido do usu�rio.
     *
     * @return Pr�ximo recado ou null se n�o houver recados
     */
    public Recado lerRecado() {
        return recados.poll();
    }

    // Comunidades

    /**
     * Obt�m o conjunto de comunidades �s quais o usu�rio pertence.
     *
     * @return Conjunto de nomes de comunidades
     */
    public Set<String> getComunidades() {
        return comunidades;
    }

    /**
     * Adiciona o usu�rio a uma comunidade.
     *
     * @param comunidade Nome da comunidade
     */
    public void adicionarComunidade(String comunidade) {
        comunidades.add(comunidade);
    }

    // Mensagens

    /**
     * Adiciona uma nova mensagem para o usu�rio.
     *
     * @param mensagem Mensagem a ser adicionada
     */

    public void adicionarMensagem(Mensagem mensagem) {
        mensagens.add(mensagem);
        if (notificacaoStrategy != null) {
            notificacaoStrategy.enviarNotificacao(this.login,
                    "Nova mensagem em " + mensagem.getComunidade() + ": " + mensagem.getTexto());
        }
    }

    /**
     * L� e remove a pr�xima mensagem n�o lida do usu�rio.
     *
     * @return Pr�xima mensagem ou null se n�o houver mensagens
     */
    public Mensagem lerMensagem() {
        return mensagens.poll();
    }

    /**
     * Verifica se o usu�rio tem mensagens n�o lidas.
     *
     * @return true se houver mensagens n�o lidas, false caso contr�rio
     */
    public boolean temMensagens() {
        return !mensagens.isEmpty();
    }

    // F�s e �dolos

    /**
     * Adiciona um �dolo para o usu�rio.
     *
     * @param idolo Login do �dolo a ser adicionado
     */
    public void adicionarIdolo(String idolo) {
        idolos.add(idolo);
    }

    /**
     * Verifica se o usu�rio � f� de outro usu�rio.
     *
     * @param idolo Login do poss�vel �dolo
     * @return true se for f�, false caso contr�rio
     */
    public boolean ehFa(String idolo) {
        return idolos.contains(idolo);
    }

    /**
     * Adiciona um f� para o usu�rio.
     *
     * @param fa Login do f� a ser adicionado
     */
    public void adicionarFa(String fa) {
        fas.add(fa);
    }

    /**
     * Obt�m o conjunto de f�s do usu�rio.
     *
     * @return Conjunto de logins dos f�s (c�pia defensiva)
     */
    public Set<String> getFas() {
        return new HashSet<>(fas); // c�pia defensiva
    }

    // Paquera

    /**
     * Adiciona uma paquera para o usu�rio.
     *
     * @param paquera Login da paquera a ser adicionada
     */
    public void adicionarPaquera(String paquera) {
        paqueras.add(paquera);
    }

    /**
     * Verifica se o usu�rio tem uma paquera por outro usu�rio.
     *
     * @param paquera Login da poss�vel paquera
     * @return true se for paquera, false caso contr�rio
     */
    public boolean ehPaquera(String paquera) {
        return paqueras.contains(paquera);
    }

    /**
     * Obt�m o conjunto de paqueras do usu�rio.
     *
     * @return Conjunto de logins das paqueras
     */
    public Set<String> getPaqueras() {
        return paqueras;
    }

    // Inimigos

    /**
     * Adiciona um inimigo para o usu�rio.
     *
     * @param inimigo Login do inimigo a ser adicionado
     */
    public void adicionarInimigo(String inimigo) {
        inimigos.add(inimigo);
    }

    /**
     * Verifica se outro usu�rio � inimigo deste usu�rio.
     *
     * @param outro Login do poss�vel inimigo
     * @return true se for inimigo, false caso contr�rio
     */
    public boolean ehInimigo(String outro) {
        return inimigos.contains(outro);
    }

    /**
     * Obt�m o conjunto de �dolos do usu�rio.
     *
     * @return Conjunto de logins dos �dolos
     */
    public Set<String> getIdolos() {
        return idolos;
    }

    /**
     * Obt�m o conjunto de inimigos do usu�rio.
     *
     * @return Conjunto de logins dos inimigos
     */
    public Set<String> getInimigos() {
        return inimigos;
    }

    /**
     * Define a estrat�gia de notifica��o
     * @param strategy Nova estrat�gia de notifica��o
     */
    public void setNotificacaoStrategy(NotificacaoStrategy strategy) {
        this.notificacaoStrategy = strategy;
    }

}
package br.ufal.ic.p2.jackut.Models;

import java.io.Serializable;

/**
 * Classe que representa um recado enviado entre usu�rios no sistema Jackut.
 * Implementa Serializable para permitir serializa��o.
 *
 * <p>Cada recado cont�m o remetente e o texto da mensagem.</p>
 *
 * @author Sistema Jackut
 * @version 1.0
 */
public class Recado implements Serializable {
    private static final long serialVersionUID = 1L;
    private String remetente;
    private String texto;

    /**
     * Constr�i um novo recado com os dados fornecidos.
     *
     * @param remetente Login do usu�rio remetente
     * @param texto Conte�do do recado
     */
    public Recado(String remetente, String texto) {
        this.remetente = remetente;
        this.texto = texto;
    }

    /**
     * Obt�m o login do remetente do recado.
     *
     * @return Login do remetente
     */
    public String getRemetente() {
        return remetente;
    }

    /**
     * Obt�m o texto do recado.
     *
     * @return Conte�do do recado
     */
    public String getTexto() {
        return texto;
    }
}
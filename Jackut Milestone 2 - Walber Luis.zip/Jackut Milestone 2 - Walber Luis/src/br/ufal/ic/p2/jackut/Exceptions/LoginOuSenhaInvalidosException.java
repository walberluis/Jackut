package br.ufal.ic.p2.jackut.Exceptions;

/**
 * Exce��o lan�ada quando as credenciais fornecidas (login ou senha) s�o inv�lidas durante o login.
 */
public class LoginOuSenhaInvalidosException extends RuntimeException {
    /**
     * Constr�i a exce��o com uma mensagem padr�o sobre credenciais inv�lidas.
     */
    public LoginOuSenhaInvalidosException() {
        super("Login ou senha inv�lidos.");
    }
}


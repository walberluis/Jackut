package br.ufal.ic.p2.jackut.Exceptions;

/**
 * Exce��o lan�ada quando um usu�rio tenta estabelecer um relacionamento consigo mesmo,
 * o que n�o � permitido pelo sistema.
 */
public class RelacionamentoProibidoException extends RuntimeException {
    /**
     * Constr�i a exce��o com o tipo de relacionamento proibido.
     *
     * @param mensagem O tipo de relacionamento inv�lido (ex: "amigo", "inimigo")
     */
    public RelacionamentoProibidoException(String mensagem) {
        super("Usu�rio n�o pode ser " + mensagem + " de si mesmo.");
    }
}
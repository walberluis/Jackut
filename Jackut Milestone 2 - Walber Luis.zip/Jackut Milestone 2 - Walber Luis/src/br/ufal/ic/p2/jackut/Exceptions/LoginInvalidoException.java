package br.ufal.ic.p2.jackut.Exceptions;

/**
 * Exce��o lan�ada quando � fornecido um login inv�lido (vazio ou nulo) durante o cadastro.
 */
public class LoginInvalidoException extends RuntimeException {
    /**
     * Constr�i a exce��o com uma mensagem padr�o sobre login inv�lido.
     */
    public LoginInvalidoException() {
        super("Login inv�lido.");
    }
}
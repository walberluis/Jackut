package br.ufal.ic.p2.jackut.Exceptions;

/**
 * Exce��o lan�ada quando um usu�rio tenta adicionar outro usu�rio em um relacionamento
 * (como amigo, �dolo, paquera ou inimigo) onde esse relacionamento j� existe.
 */
public class UsuarioJaAdicionadoException extends RuntimeException {
  /**
   * Constr�i a exce��o com uma mensagem espec�fica do tipo de relacionamento.
   *
   * @param mensagem O tipo de relacionamento que j� existe (ex: "amigo", "�dolo")
   */
  public UsuarioJaAdicionadoException(String mensagem) {
    super("Usu�rio j� est� adicionado como " + mensagem + ".");
  }
}